from pyspark.sql import SparkSession
from pyspark import SparkContext
import sys
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from com.maxlifeinsurance.framework.factory.ClassFactory import ClassFactory as cf
from com.maxlifeinsurance.framework.utils.ConfigUtils import ConfigUtils
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
import logging as logs


def main():
    sc = SparkContext()
    glueContext = GlueContext(sc)

    StartTime = F.TimeNow()
    logs.basicConfig()
    logs.getLogger().setLevel(logs.INFO)
    logs.info("::::Job Start Time {}".format(StartTime))

    job = Job(glueContext)
    config = ConfigUtils().getConfig()

    job_name = "Manual_Preprocess_Job"

    global args
    
    sys.argv += ["--job_name", job_name]
    args = getResolvedOptions(sys.argv, "--job_name")

    print("Main arguments passed:",args)
    print("arguments length",len(vars(args)))
    

    spark = SparkSession.builder.appName(job_name) \
        .config("spark.sql.parquet.writeLegacyFormat", "true") \
        .config('spark.driver.extraJavaOptions', '-Duser.timezone=GMT+5:30') \
        .config('spark.executor.extraJavaOptions', '-Duser.timezone=GMT+5:30') \
        .getOrCreate()

    print("1--")
    job.init(args['JOB_NAME'], args)
    print("1222--")

    logs.info('::::Executing Job {}'.format(str(job_name)))
    logs.info("::::The Glue Job {} is starting".format(job_name))
    Job_Instance = cf.getJobClass(spark, glueContext, config, job_name)
    res = Job_Instance.execute(args)
    
    logs.info('::::[JOB NAME {job} RESULT: {result}]'.format(job=job_name, result=res))
    spark.stop()
    logs.info("::::Job {} has Successfully Completed.".format(job_name))


if __name__ == '__main__':
    main()