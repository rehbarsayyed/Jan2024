from pyspark.sql import *
from pyspark.sql.functions import col, lit, upper, lower
import boto3
from pytz import timezone
import pytz
from datetime import datetime
from functools import *
import json
import re
import logging as logs


class DFUtils(object):

    # Check Input S3 Path exist or not in respective S3 bucket.
    @staticmethod
    def s3_Path_Exists(Path) -> bool:
        s3 = boto3.resource('s3')
        Bucket = Path.split("/")[2]
        Key = Path.replace("s3://" + Bucket + "/", "")
        bucket = s3.Bucket(Bucket)
        Path_Exist = lambda key: bool(list(bucket.objects.filter(Prefix=key)))
        return Path_Exist(Key)

    # Check Input S3 Folder/File exist or not in input S3 bucket.
    @staticmethod
    def s3_File_Exists(Bucket, Path) -> bool:
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(Bucket)
        Path_Exist = lambda key: bool(list(bucket.objects.filter(Prefix=key)))
        return Path_Exist(Path)

    # Check Input Column exist or not in input Spark Dataframe.
    @staticmethod
    def colExist(df:DataFrame,column) -> bool:
       return bool(column.lower() in list(map(lambda x: x.strip(' ').lower(), df.columns)))

    # Get Current Local(Indian) Timestamp
    @staticmethod
    def TimeNow(date_format = '%Y-%m-%d %H:%M:%S') -> str:
        date = datetime.now(tz=pytz.utc)
        date = date.astimezone(timezone('Asia/Calcutta'))
        return str(date.strftime(date_format))

    @staticmethod
    def UTCDateNow() -> str:
        date_format = '%Y-%m-%d'
        date = datetime.now(tz=pytz.utc)
        return str(date.strftime(date_format))

    # Get Current Local(Indian) Date
    @staticmethod
    def TodaysDate() -> str:
        date_format = '%Y-%m-%d'
        date = datetime.now(tz=pytz.utc)
        date = date.astimezone(timezone('Asia/Calcutta'))
        return str(date.strftime(date_format))

    @staticmethod
    def EpochTime() -> int:
        date = datetime.now(tz=pytz.utc)
        date = date.astimezone(timezone('Asia/Calcutta'))
        epochTime = int(date.timestamp())
        return epochTime
    # Method to Convert all columns name of input Spark Dataframe into Lowercase
    @staticmethod
    def toLowerCaseColumnName(df:DataFrame) -> DataFrame:
        newdf = (reduce(lambda tdf,col_name: tdf.withColumnRenamed(col_name, str(col_name).lower()),df.columns,df))
        return newdf

    # Method to remove prefix from all columns of Dataframe. Example: column "fnl_pol_id" --> "pol_id" if "fnl_" in pass
    # as a prefix.
    @staticmethod
    def toRemovePrefixFromColumn(df:DataFrame,prefix:str) -> DataFrame:
        newdf = (reduce(lambda tdf,col_name: tdf.withColumnRenamed(col_name, str(col_name).replace(prefix,"",1)),df.columns,df))
        return newdf

    # Add all list of columns into Dataframe with Empty/Null value.
    @staticmethod
    def toAddEmptyColumn(df:DataFrame,colList:list) -> DataFrame:
        newdf = (reduce(lambda tdf,col_name: tdf.withColumn(col_name, lit("")),colList,df))
        return newdf

    # Convert all columns datatype into String of Dataframe.
    @staticmethod
    def castColsToString(df: DataFrame) -> DataFrame:
        newdf = (reduce(lambda tdf, col_name: tdf.withColumn(col_name, col(col_name).cast("String")), df.columns, df))
        return newdf

    # To compare Column List.
    @staticmethod
    def ColumnsCompare(old:list, new:list) -> (list,list):
       if set(old) != set(new):
           allColset = set(old) | set(new)
           notInold = list(allColset - set(old))
           notInnew = list(allColset - set(new))
           return (notInold,notInnew)
       else:
           return ([],[])

    # Strip SQL margin and Pipe
    @staticmethod
    def strip_margin(text):
        return re.sub('\n[ \t]*\|', '\n', text)

    # Replace double Slash into Single Slash from S3 Bucket Path.
    @staticmethod
    def s3Path(Path:str):
        return "s3://" + Path.split("s3://")[1].replace("//", "/")

    # Method to get Job Bookmark value.
    @staticmethod
    def getJobBookmark(JobName):
        client = boto3.client('glue')
        response = client.get_job_bookmark(
            JobName=JobName
        )
        jb = response['JobBookmarkEntry']['JobBookmark']
        print(jb)
        return jb

    @staticmethod
    def getObjectCount(parentPath,ObjList):
        bucketName = parentPath.split("/")[2]
        bucketKey = "s3://" + bucketName + "/"
        prefixList = [str(x).replace(bucketKey,"") for x in ObjList]
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(bucketName)
        objCount = 0
        for x in prefixList:
            objCount = objCount + sum(1 for _ in bucket.objects.filter(Prefix=str(x)))
        return objCount

    @staticmethod
    def delObject(parentPath,ObjList):
        bucketName = parentPath.split("/")[2]
        bucketKey = "s3://" + bucketName + "/"
        prefixList = [str(x).replace(bucketKey,"") for x in ObjList]
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(bucketName)
        for x in prefixList:
            bucket.objects.filter(Prefix=str(x)).delete()

    @staticmethod
    def copyFromS3ToS3(src, target):
        s3 = boto3.resource('s3')
        tarBucket = target.split("/")[2]
        srcBucket = src.split("/")[2]
        srcKey = src.replace("s3://" + srcBucket + "/", "")
        tarKey = target.replace("s3://" + tarBucket + "/", "")
        copy_source = {'Bucket': srcBucket, 'Key': srcKey}
        s3.meta.client.copy(copy_source, tarBucket, tarKey)

    @staticmethod
    def putJsonObject(data, path):
        try:
            s3 = boto3.client('s3')
            Bucket = path.split("/")[2]
            Key = path.replace("s3://" + Bucket + "/", "")
            s3.put_object(Body=json.dumps(data), Bucket=Bucket, Key=Key, ContentType="application/json")
            return "Success"
        except Exception as e:
            return ("Exception - " + str(e))

    @staticmethod
    def getIdealPartition(args):
        JobRunID = args['JOB_RUN_ID']
        JobName = args['JOB_NAME']
        part = 50
        client = boto3.client('glue')
        response = client.get_job_run(JobName=JobName,RunId=JobRunID, PredecessorsIncluded=True)
        NumWorkers = response['JobRun']['NumberOfWorkers']
        WorketType = response['JobRun']['WorkerType']
        print("Number of Workers --> " + str(NumWorkers))
        print("Worker Type --> " + str(WorketType))
        if str(WorketType).upper() == "STANDARD":
            numExecutors  = (int(NumWorkers) - 1) * 2 - 1
            part = int(4 * numExecutors)
        elif str(WorketType).upper() == "G.1X":
            numExecutors = (int(NumWorkers)-1)
            part = int(8 * numExecutors)
        elif str(WorketType).upper() == "G.2X":
            numExecutors = (int(NumWorkers)-1)
            part = int(16 * numExecutors)
        print("Number of Partition Calculated  --> " + str(part))
        return part

    @staticmethod
    def AuditLog(spark, Config, args):
        try:
            AuditMsg = ""
            if Config.has_section('Audit'):
                if Config.has_option('Audit', 'Audit.s3.path'):
                    AuditPath = Config.get('Audit', 'Audit.s3.path')
                    timeFormat = '%Y-%m-%d %H:%M:%S'
                    dateFormat = '%Y-%m-%d'
                    TodayDate = DFUtils.TimeNow(dateFormat)
                    client = boto3.client('glue')
                    response = client.get_job_run(JobName=args['JOB_NAME'], RunId=args['JOB_RUN_ID'],
                                                  PredecessorsIncluded=True)
                    AuditDict = {}
                    AuditDict['GlueJobName'] = args['JOB_NAME']
                    AuditDict['JobName'] = args['JobName']
                    AuditDict['JobRunId'] = args['JOB_RUN_ID']
                    AuditDict['Worker'] = str(response['JobRun']['NumberOfWorkers'])
                    AuditDict['WorkerType'] = response['JobRun']['WorkerType']
                    AuditDict['JobInputParameter'] = args['jobName']
                    AuditDict['JobStartTime'] = args['JobStartTime']
                    AuditDict['JobEndTime'] = DFUtils.TimeNow()
                    ExecutionTime = datetime.strptime(AuditDict['JobEndTime'], timeFormat) - datetime.strptime(
                        AuditDict['JobStartTime'], timeFormat)
                    AuditDict['JobExecutionTimeInMinute'] = str(round(ExecutionTime.total_seconds() / 60,2))
                    AuditDict['JobRunState'] = args['JobResult']
                    AuditDict['JobMessage'] = args['JobMessage']
                    AuditDict['AuditDate'] = TodayDate
                    if Config.has_option('Audit', 'Audit.custom.keys'):
                        CustomKeys = Config.get('Audit', 'Audit.custom.keys')
                        CustomKeyList = set(map(lambda x: x.strip(), CustomKeys.split(",")))
                        argsList = list(args.keys())
                        AuditKeyList = list(AuditDict)
                        logs.info("::::Audit - Custom Audit attributes {}".format(CustomKeyList))
                        for x in CustomKeyList:
                            if x not in AuditKeyList:
                                if x not in argsList:
                                    logs.warning("::::Audit - Custom Audit attribute '{}' is Missing.".format(x))
                                    AuditDict[x] = ''
                                else:
                                    AuditDict[x] = args[x]
                    rw = Row(**AuditDict)
                    df = spark.createDataFrame([rw]).cache()
                    validFormat = ['Parquet', "Csv", "Json"]
                    if Config.has_option('Audit', 'Audit.output.format'):
                        AuditFileFormat = Config.get('Audit', 'Audit.output.format').title().strip()
                        if AuditFileFormat == "":
                            AuditFileFormat = "Json"
                        else:
                            if AuditFileFormat not in validFormat:
                                AuditMsg = "The Output format {} for Auditiing is not valid. The valid formats are {}".format(
                                    AuditFileFormat, validFormat)
                                df.show(truncate=False)
                    else:
                        AuditFileFormat = "Json"

                    if AuditFileFormat == "Json":
                        df.coalesce(1).write.partitionBy("AuditDate").mode("append").json(AuditPath)
                    elif AuditFileFormat == "Parquet":
                        df.coalesce(1).write.partitionBy("AuditDate").mode("append").parquet(AuditPath)
                    elif AuditFileFormat == "Csv":
                        df.coalesce(1).write.partitionBy("AuditDate").mode("append").option("header", "true").csv(AuditPath)
                    else:
                        AuditMsg = "The Output format {} for Auditiring is not valid. The valid formats are {}".format(
                            AuditFileFormat, validFormat)
                else:
                    AuditMsg = "The Option 'Audit.s3.path' is Mandatory in section 'Audit' Since Audit is Enable. Either disable Audit or Provide S3 Path in the Config.properties file."
            else:
                AuditMsg = "The Section 'Audit' is Mandatory Since Audit is Enable. Either disable Audit or Add Audit Section with mandatory options in the Config.properties file."

            return AuditMsg
        except Exception as e:
            return ("Error while Auditing :- " + str(e))

    @staticmethod
    def CreateView(spark, dd):
        for x in dd:
            View = x["View"]
            Qry = x["Sql"]
            spark.sql(Qry).createOrReplaceTempView(View)

    @staticmethod
    def ExecuteFuntion(spark, Config, df, Id):
        try:
            Id = str(Id).upper()
            JsonPath = Config.get('Environment', 'S3.mapping.config.path')
            MapJsonDF = spark.read.option("multiLine", "true").json(JsonPath) \
                .filter(upper(col("API")) == upper(lit(Id))) \
                .withColumn("Order", col("Order").cast("Int"))
            LogicList = [x.Logic for x in MapJsonDF.orderBy("Order").select("Logic").collect()]
            Logic = ".".join([str(x).strip(' ') + str("\\") + str("\n") for x in LogicList])
            Codes = """from pyspark.sql import SparkSession\nfrom pyspark import SparkContext\nfrom pyspark.sql.types import StructType,StructField, StringType\nfrom pyspark.sql.functions import *\nfrom pyspark.sql import Window\ndef fun (df):\n\tdf1 = df.""" + Logic + """\n\treturn df1"""
            logs.info("::::Executing Below Code")
            logs.info(Codes)
            exec(Codes, globals())

            df1 = fun(df)
            return ("Success", df1)
        except Exception as e:
            logs.error(str(e))
            return ("Failed :-" + str(e), df)

    @staticmethod
    def getProperties(secret, engine=None):
        if 'engine' not in secret.keys() and engine is None:
            msg = "Database engine not found in Secret."
            logs.error(msg)
            raise ValueError(msg)
        elif 'engine' not in secret.keys() and engine is not None:
            secret['engine'] = engine.strip()

        if secret['engine'].lower() == 'mysql':
            secret['url'] = "jdbc:mysql://{}:{}/{}".format(secret['host'], str(secret['port']), secret['dbname'])
            secret['driver'] = "com.mysql.jdbc.Driver"
        elif secret['engine'].lower() == 'postgres':
            secret['url'] = "jdbc:postgresql://{}:{}/{}".format(secret['host'], str(secret['port']), secret['dbname'])
            secret['driver'] = "org.postgresql.Driver"
        elif secret['engine'].lower() == 'redshift':
            secret['url'] = "jdbc:redshift://{}:{}/{}".format(secret['host'], str(secret['port']), secret['dbname'])
            secret['driver'] = "com.amazon.redshift.jdbc42.Driver"
        elif secret['engine'].lower() == 'oracle':
            secret['url'] = "jdbc:oracle:thin:@//{}:{}:{}".format(secret['host'], str(secret['port']), secret['dbname'])
            secret['driver'] = "oracle.jdbc.driver.OracleDriver"
        else:
            msg = f"Not supported database engine --> {secret['engine']} found."
            logs.error(msg)
            raise ValueError(msg)
        properties = dict(driver=secret['driver'], user=secret['username'], password=secret['password'])
        return (secret, properties)
