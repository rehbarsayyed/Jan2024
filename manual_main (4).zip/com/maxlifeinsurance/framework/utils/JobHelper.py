import datetime
import boto3
import json
import logging
import botocore

logger = logging.getLogger('__NAME__')
logger.setLevel(logging.INFO)


# This method use by Segregation JOb only. It give timestamp of preview successfull Glue job completion and also check
# return list of files/Table from Staging bucket that are get modified after last run.

class JobHelper:
    @staticmethod
    def fetch_previous_glue_job(jobName):
        client = boto3.client('glue')
        response = client.get_job_runs(JobName=jobName)
        last_modified_date_list = []
        for i in range(len(response['JobRuns'])):
            if response['JobRuns'][i]['JobRunState'] == 'SUCCEEDED':
                last_modified_date = response['JobRuns'][i]['StartedOn']
                last_modified_date_list.append(last_modified_date)
            else:
                logger.info("::::Skipping failed job ")

        # table_list = []
        if not last_modified_date_list:
            # hardcoded time if no previous job runs exist
            last_modified_date = datetime.datetime(2020, 1, 1)
        else:
            last_modified_date = max(dt for dt in last_modified_date_list)

        last_modified_date = last_modified_date.replace(tzinfo=None)
        logger.info("::::Last Run of Glue Job was at {}".format(last_modified_date))
        return last_modified_date

    @staticmethod
    def fetch_updated_tables_list(last_modified_date, Path, Stagebucket, SrcDir, Source):
        now = datetime.datetime.now()
        current_time = now.strftime("%d/%m/%Y %H:%M:%S")
        # counter = 0
        s3 = boto3.resource('s3')
        bucket = Path.split("/")[2]
        key = Path.replace("s3://" + bucket + "/", "")
        data = s3.Object(bucket, key)
        json_data = data.get()['Body'].read().decode('utf-8')
        jsonFile = json.loads(json_data)
        table_list = []
        # find latest time of each table and record table name
        for i in range(len(jsonFile)):
            table = jsonFile[i]['Table']
            schema = jsonFile[i]['Schema']
            source = jsonFile[i]['Source']

            if source == Source:
                prefix_val = SrcDir + '/' + str(schema).upper() + '/' + str(table).upper() + '/'
                target = s3.Bucket(Stagebucket)

                for file in target.objects.filter(Prefix=prefix_val):
                    file_modified_date = file.last_modified.replace(tzinfo=None)
                    if file_modified_date >= last_modified_date:
                        key = file.key
                        updated_table = key.split('/')[2]
                        table_list.append(
                            {'Source': source, 'Schema': schema, 'Table': updated_table, 'UpdatedTime': current_time})
                        break

        return table_list
