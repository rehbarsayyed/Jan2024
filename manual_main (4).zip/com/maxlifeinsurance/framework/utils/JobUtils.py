from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from com.maxlifeinsurance.framework.factory.ClassFactory import ClassFactory as cf
from com.maxlifeinsurance.framework.utils.SecretUtils import SecretUtils as Sr
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import logging as logs
from pyspark.sql import Window
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.types import StructType, StructField
from com.maxlifeinsurance.framework.utils.ConnectionUtils import ConnectionUtils as con


class JobUtils(object):
    @staticmethod
    def getSourceTablesList(spark, path, source, schema=None, Group=None):
        """
        Get list of tables for an input Source (and Schema if it not None) mentioned in TableMaster.json
        :param spark - Spark Session
        :param path - TableMaster.json s3 Path
        :param source - Name of Source defined in TableMaster.json
        :param schema - Name of Schema for a Source defined in TableMaster.json [Default - None]
        :param Group - Name of Group, if tables are defined in a Group. [Default - None]

        :return list of tables
        """
        df = spark.read.option("multiLine", "true").json(path)
        if schema is None:
            if Group is None:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))))
            else:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Group")) == upper(lit(Group))))
        else:
            if Group is None:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Schema")) == upper(lit(schema))))
            else:
                df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                                (upper(col("Schema")) == upper(lit(schema))) &
                                (upper(col("Group")) == upper(lit(Group))))
        dfCount = df1.count()
        if dfCount == 0:
            if schema is None:
                logs.warning(f"::::No tables found for the source {source}")
            else:
                logs.warning(f"::::No tables found for the source {source} and Schema {schema}.")
            details = {}
        else:
            details = [x.asDict() for x in df1.select(col("Source"), col("Table")).collect()]
        return details

    @staticmethod
    def getTableDetails(session, path, source, schema, table, mode='spark'):
        """
        Get table details for a source and schema mentioned in TableMaster.json
        :param session: Spark Session or Glue Context
        :param path - TableMaster.json s3 Path
        :param source - Name of Source defined in TableMaster.json
        :param schema - Name of Schema for a Source defined in TableMaster.json
        :param table - Name of Table
        :param mode - mode of session, possible value - spark or glue.[Default - spark]

        :return list of table details
        """
        if mode == 'spark':
            df = JobUtils.readDataFromS3(spark=session, path=path, dataFormat='json')
        elif mode == 'glue':
            df = JobUtils.readDataFromS3UsingGlue(glueContext=session, path=path, dataFormat='json')
        else:
            raise ValueError(f"Invalid read mode found {mode}")
        df1 = df.filter((upper(col("Source")) == upper(lit(source))) &
                        (upper(col("Schema")) == upper(lit(schema))) &
                        (upper(col("Table")) == upper(lit(table))))
        dfCount = df1.count()
        if dfCount == 0:
            logs.warning(f"::::Table '{schema}.{table}' details not found for the source {source}.")
            details = {}
        elif dfCount == 1:
            details = df1.collect()[0].asDict()
            for x in details:
                if ',' in details[x]:
                    details[x] = list(map(lambda y: y.strip(' ').lower(), details[x].split(",")))
                elif details[x].strip() == '':
                    details[x] = None
        else:
            msg = f"Duplicate record found for Source ' {source} ' and Table '{schema}.{table}' in TableMaster. "
            logs.error(msg)
            raise ValueError(msg)
        return details

    @staticmethod
    def readDataFromS3(spark, path, dataFormat):
        """
        Read data from S3 using Spark Session.
        :param spark: Spark Session
        :param path - input s3 data Path
        :param dataFormat - data format, Possible format parquet, json, csv, avro, orc.

        :return dataframe
        """
        try:
            if dataFormat.lower() == 'parquet':
                df = spark.read.parquet(path)
            elif dataFormat.lower() == 'json':
                df = spark.read.option("multiLine", "true").json(path)
            elif dataFormat.lower() == 'csv':
                df = spark.read.option("header", "true").csv(path)
            elif dataFormat.lower() == 'avro':
                df = spark.read.avro(path)
            elif dataFormat.lower() == 'orc':
                df = spark.read.orc(path)
            else:
                msg = f"No read method found for format {dataFormat}"
                logs.warning(msg)
                raise ValueError(msg)
            return df
        except Exception as e:
            logs.error(e)
            raise Exception(str(e))

    @staticmethod
    def readDataFromS3UsingGlue(glueContext, path, dataFormat, transformation_ctx=None):
        """
        Read data from S3 using Glue Context.
        :param glueContext: Glue Context
        :param path - input s3 data Path
        :param dataFormat - data format, Possible format parquet, json, csv, avro, orc.
        :param transformation_ctx - applicable when JobBookmark enable. Key to maintain the state of input path.

        :return dataframe
        """
        try:
            if transformation_ctx is None:
                ctx = F.EpochTime()
            else:
                ctx = transformation_ctx
            dataFormat = dataFormat.strip()
            if dataFormat.lower() == 'parquet':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='parquet',
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'json':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='json',
                                                                           format_options={"multiline": True},
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'csv':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='csv',
                                                                           format_options={"withHeader": True},
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'avro':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='avro',
                                                                           transformation_ctx=ctx)
            elif dataFormat.lower() == 'orc':
                datasource = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                           connection_options={"path": path,
                                                                                               "recurse": True},
                                                                           format='orc',
                                                                           transformation_ctx=ctx)
            else:
                msg = f"No read method found for format {dataFormat}"
                logs.warning(msg)
                raise ValueError(msg)
            df = datasource.toDF()
            return df
        except Exception as e:
            logs.error(e)
            raise Exception(str(e))

    @staticmethod
    def AddMandateColumn(Config, df, Options):
        """
        Add Mandatory Columns Operation and watermark columns into dataframe if not available.
        :param Config: Config object of properties file.
        :param df - input dataframe where columns need to add.
        :param Options - Dict of operation and watermark column.

        :return dataframe
        """
        global_opColumn = Config.get('Datalake', 'datalake.operation.column')
        global_WColumn = Config.get('Datalake', 'datalake.watermark.column')
        if Options != '{}':
            opColumn = Options['OperationColumn'] if 'OperationColumn' in Options.key() else global_opColumn
            WColumn = Options['WatermarkColumn'] if 'WatermarkColumn' in Options.key() else global_WColumn
        else:
            opColumn = global_opColumn
            WColumn = global_WColumn

        if opColumn.strip() == '':
            df1 = df
        elif F.colExist(df, opColumn):
            df1 = df.withColumn(opColumn, when(col(opColumn).isNull(), lit("I")).otherwise(col(opColumn)))
        else:
            df1 = df.withColumn(opColumn, lit("I"))

        if WColumn.strip() == '':
            df2 = df1
        elif F.colExist(df1, "edl_created_at"):
            df2 = df1
        else:
            df2 = df1.withColumn("edl_created_at", rpad(concat((unix_timestamp(col(WColumn))),
                                                               coalesce(split(col(WColumn), "\\.")[1], lit("0"))),
                                                        16, '0').cast("long"))
        return df2

    @staticmethod
    def readTableFromS3UsingGlueOptions(glueContext, Config, Source, Schema,
                                        Table, dataLayer, dataFormat='parquet'):
        """
        Read DataLake table from s3 using Glue Context.
        :param glueContext: Glue Context.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param Schema: Table Schema Name.
        :param Table:  Table Name.
        :param dataLayer:  DataLake layer Name such as Raw, Stage, Mirror etc.( as per defined in properties file).
        :param dataFormat - data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]

        :return records count and dataframe
        """
        parentPath = Config.get(dataLayer.strip().title(), dataLayer.lower() + '.bucket.path')
        SrcDirProp = str(Source).upper() + '.' + dataLayer.lower() + str('.dir')
        SrcDir = Config.get(str(Source).upper(), SrcDirProp)
        Path = parentPath + str("/") + SrcDir + str("/") + str(Schema).upper() + str("/") + str(Table).upper() + str(
            "/*")
        FilePath = F.s3Path(Path)
        if Schema.strip() == '':
            SchemaTable = Table.strip()
        else:
            SchemaTable = Schema.strip() + str("_") + Table.strip()
        logs.info("[{}]::::Input Source Table {} Path is {}".format(dataLayer.title(), Table, FilePath))
        df = JobUtils.readDataFromS3UsingGlue(glueContext, FilePath, dataFormat, transformation_ctx=SchemaTable)
        Count = df.count()
        if Count != 0:
            JsonPath = Config.get('Environment', 's3.table.master.path')
            table_details = JobUtils.getTableDetails(glueContext, JsonPath, Source, Schema, Table, mode='glue')
            df1 = JobUtils.AddMandateColumn(Config, df, Options=table_details)
            return (Count, df1)
        return (Count, df)

    # Getting incremental data using Glue job bookmark by using Glue Catalog database Tables
    # Use this method when tables are created in Glue Catalog and table has Watermark Column.
    @staticmethod
    def readTableUsingGlueCatalog(glueContext, Config, Source, database, table, pushDownPredicate=None):
        """
        Read table from source database using Glue Context and glue Catalog.
        :param glueContext: Glue Context.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param database: Table datbase name from Glue Catalog.
        :param table:  Name of catalog table.
        :param pushDownPredicate:  Filter push-down properties

        :return records count and dataframe
        """
        JsonPath = Config.get('Environment', 's3.table.master.path')
        table_details = JobUtils.getTableDetails(glueContext, JsonPath, Source, database, table, mode='glue')
        WColumn = str(table_details['WatermarkColumn'])
        ctx = database + '.' + table
        if WColumn.strip() != "":
            if pushDownPredicate is None:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table,
                                                                            transformation_ctx=ctx,
                                                                            additional_options={
                                                                                "jobBookmarkKeys": [WColumn],
                                                                                "jobBookmarksKeysSortOrder": "asc"})
            else:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table,
                                                                            transformation_ctx=ctx,
                                                                            push_down_predicate=pushDownPredicate,
                                                                            additional_options={
                                                                                "jobBookmarkKeys": [WColumn],
                                                                                "jobBookmarksKeysSortOrder": "asc"})
        else:
            if pushDownPredicate is None:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table)
            else:
                datasource0 = glueContext.create_dynamic_frame.from_catalog(database=database,
                                                                            table_name=table,
                                                                            push_down_predicate=pushDownPredicate)

        Count = datasource0.count()
        df = datasource0.toDF()
        return (Count, df)

    @staticmethod
    def readTableFromS3(spark, Config, Source, Schema, Table, dataLayer, Latest=True, dataFormat='parquet'):
        """
        Read table from  s3 DataLake using Spark.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param Source: Table Source Name.
        :param Schema: Table Schema Name.
        :param Table:  Name of data lake table.
        :param dataLayer: DataLake layer Name such as Raw, Stage, Mirror etc.( as per defined in properties file).
        :param Latest: Flag to get latest snapshot of table. [default - True]
        :param dataFormat: data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]

        :return dataframe
        """
        parentPath = Config.get(dataLayer.strip().title(), dataLayer.lower() + '.bucket.path')
        SrcDirProp = str(Source).upper() + '.' + dataLayer.lower() + str('.dir')
        SrcDir = Config.get(str(Source).upper(), SrcDirProp)
        Path = parentPath + str("/") + SrcDir + str("/") + str(Schema).upper() + str("/") + str(Table).upper() + str(
            "/*")
        FilePath = F.s3Path(Path)
        logs.info("[{}]::::Input Source Table {} Path is {}".format(dataLayer.title(), Table, FilePath))
        df = JobUtils.readDataFromS3(spark, FilePath, dataFormat)
        JsonPath = Config.get('Environment', 's3.table.master.path')
        table_details = JobUtils.getTableDetails(spark, JsonPath, Source, Schema, Table, mode='spark')
        df1 = JobUtils.AddMandateColumn(Config, df, Options=table_details)
        if Latest:
            df2 = JobUtils.getLatestData(spark, Config, df1, Source, Schema, Table)
        else:
            df2 = df1
        return df2

        # Reading Data from RDS using Spark Utility.
        # @Source - This is the name of the source defined in Connection Utils. For example RedShift
        #

    @staticmethod
    def readFromJDBC(spark: SparkSession, schema, tableName, secret_name, Options=None, region_name='ap-south-1'):
        """
        Read table data from source database using spark JDBC.
        :param spark: spark Session.
        :param schema: Table Schema Name.
        :param tableName:  Table Name.
        :param secret_name: AWS Secret manager name to get database credentials
        :param Options: Additional Spark JDBC Options[default - None]
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return dataframe
        """
        try:
            secret1 = Sr.getSecret(secret_name, region_name=region_name)
            secret, Properties = F.getProperties(secret1)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        table = str(schema) + str(".") + str(tableName)

        default_properties = {"url": secret['url'], "dbtable": table, "numPartitions": 10, "fetchsize": 10000}
        if Options is not None:
            Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
        else:
            Prop = dict(list(default_properties.items()) + list(Properties.items()))
        df = spark.read.format("jdbc").options(**Prop).load()
        return df

    @staticmethod
    def readFromJDBCUsingQry(spark: SparkSession, Query, secret_name, Options=None, region_name='ap-south-1'):
        """
        Read table from source database using Spark
        :param spark: spark Session.
        :param Query: Custom Query.
        :param secret_name: AWS Secret manager name to get database credentials
        :param Options: Additional Spark JDBC Options[default - None]
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return dataframe
        """
        try:
            secret1 = Sr.getSecret(secret_name, region_name=region_name)
            secret, Properties = F.getProperties(secret1)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        default_properties = {"url": secret['url'], "query": Query, "numPartitions": 10, "fetchsize": 10000}
        if Options is not None:
            Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
        else:
            Prop = dict(list(default_properties.items()) + list(Properties.items()))
        df = spark.read.format("jdbc").options(**Prop).load()
        return df

    # Method to read data from DynamoDB Table.
    @staticmethod
    def readFromDynamoDb(GlueContext, Table):
        """
        Read table from DynamoDB using Glue Context and glue Catalog.
        :param GlueContext: Glue  Context.
        :param Table:  AWS DynamoDb Table Name.

        :return dataframe
        """
        try:
            datasource = GlueContext.create_dynamic_frame.from_options(connection_type="dynamodb",
                                                                       connection_options={"tableName": Table}
                                                                       )
            Count = datasource.count()
            df = datasource.toDF()
            return ("Success", Count, df)
        except Exception as e:
            logs.error(e)
            return ("Failed -" + str(e), 0, "")

    # This method implement the logic to get latest snapshot from S3 Table. It uses edl_created_at column along with tables
    # watermark column if applicable and get first row number record. it will not give latest data if table does not
    # Primary Key.
    @staticmethod
    def getLatestData(spark, Config, df, Source, Schema, Table, Del=True):
        """
        Method to Get Latest DataLake Table Data by using Primary Key and watermark column
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input Spark Dataframe
        :param Source: Source of DataLake Table
        :param Schema: Schema of DataLake Table
        :param Table:  DataLake Table Name.
        :param Del:  Flag to return delete records or not. if True then it will remove deleted records (operation is
        delete) or else not.

        :return dataframe
        """
        JsonPath = Config.get('Environment', 's3.table.master.path')
        tableDetails = JobUtils.getTableDetails(spark, JsonPath, Source, Schema, Table, mode='spark')
        PrimaryColsList = tableDetails["PrimaryColumns"]
        PriCols = ",".join([str(x) for x in PrimaryColsList])

        if (PriCols.strip(' ') != ""):
            WColumn = tableDetails["WatermarkColumn"][0]
            if F.colExist(df, "edl_created_at"):
                if WColumn != "":
                    W = Window.partitionBy(PrimaryColsList).orderBy(col("edl_created_at").desc(), col(WColumn).desc())
                else:
                    W = Window.partitionBy(PrimaryColsList).orderBy(col("edl_created_at").desc())
            elif WColumn != "":
                W = Window.partitionBy(PrimaryColsList).orderBy(col(WColumn).desc())
            else:
                W = ""
                logs.error("::::Watermark and edl_created_at columns not found.")

            newDF = df.withColumn("rn", row_number().over(W)).filter((col("rn") == lit(1))) \
                .drop("rn")

            # Removing all the records which comes with Op column as "D" in latest data
            # since these are deleted from On-Prem Source Table
            global_opColumn = Config.get('Datalake', 'datalake.operation.column')
            opColumn = tableDetails['OperationColumn'] if 'OperationColumn' in tableDetails.key() else global_opColumn
            if Del:
                df1 = newDF.filter(col(opColumn) != lit("D"))
            else:
                df1 = newDF
            return df1
        else:
            return df

    @staticmethod
    def writeDataIntoS3(df, path: str, mode="append", PartitionBy=None, dataFormat='parquet', Options=None):
        """
        Write Data into AWS S3 Path.
        :param df: spark dataframe.
        :param path: s3 output or target path.
        :param mode: Write mode, Possible values are "append", "ignore", "error", "overwrite". [default -'append'].
        :param PartitionBy: Partition by column name. [default - None].
        :param dataFormat: data format. Possible format parquet, json, csv, avro, orc. [default - Parquet]
        :param Options:  Custom Spark write options. [default - None].

        :return status ['Success'|'Failed']
        """
        try:
            mode = mode.strip().lower()
            if mode not in ["append", "ignore", "error", "overwrite"]:
                msg = f"Input write mode {mode} is invalid."
                logs.error(msg)
                raise ValueError(msg)

            if Options is None:
                Options = {}
            elif not isinstance(Options, dict):
                msg = f"Invalid Options datatype found. dict was expected."
                logs.error(msg)
                raise ValueError(msg)

            if PartitionBy is not None:
                if isinstance(PartitionBy, list):
                    PartCols = PartitionBy
                elif isinstance(PartitionBy, str):
                    PartCols = [x.strip() for x in PartitionBy.split(',')]
                else:
                    msg = f"Invalid PartitionBy type found --->{PartitionBy}. str or list type was expected."
                    logs.error(msg)
                    raise ValueError(msg)
                df.write.partitionBy(PartCols).format(dataFormat.lower()).mode(mode).options(**Options).save(path)
            else:
                df.write.format(dataFormat.lower()).mode(mode).options(**Options).save(path)

            return "Success"
        except Exception as e:
            logs.error(str(e))
            return ("Failed -" + str(e))

    # If target Database is RedShit then it is always recommended to use Dynamic Frame for writing data into RedShift.
    # instead of Spark DataFrame. Use below method to writing data into pass table.
    @staticmethod
    def writeIntoRedshift(glueContext, df, Config, source, schema, table_name, secret_name,
                          mode='append', PrimaryColumns=None, preQry=None, postQry=None, region_name='ap-south-1'):
        """
        Write Data into Redshift table using glue context.
        :param glueContext: Glue Context.
        :param df: spark dataframe.
        :param Config: Config object of properties file.
        :param source: Source defined in TableMaster for input table to get all table level detail.
        :param schema: Redshift table schema name.
        :param table_name: Redshift table name.
        :param secret_name: AWS Secret manager name to get database credentials.
        :param mode: Write mode, Possible values are "append", "truncate_write", "drop_write", "upsert". [default -'append'].
        :param PrimaryColumns: Redshift table Primary Columns. Require for Upsert mode only. [default -None].
        :param preQry: Pre-Query that need to be execute before running Copy command. [default -None].
        :param postQry: Post-Query that need to be execute after successfully completion of Copy command. [default -None].
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return status ['Success'|'Failed']
        """
        batchId = str(F.EpochTime())
        try:
            secret1 = Sr.getSecret(secret_name, region_name=region_name)
            if 'engine' not in secret1.keys():
                secret1['engine'] = 'redshift'
            secret, Properties = F.getProperties(secret1)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        glueConnectionName = Config.get('Environment', 'redshift.glue.connection.name')
        tempPath = Config.get('Environment', 'S3.redshift.temp.path')
        table = str(schema) + str(".") + str(table_name)
        target_table = table
        preAction = None
        postAction = None
        logs.info("::::Table Name is {}".format(table))
        logs.info(f"::::Connecting to URL {secret['url']}.")
        if mode.lower() in ("truncate_write", "overwrite"):
            preAction = (str(preQry) + ';' if preQry is not None else '') + f"truncate table {table};"
            postAction = postQry
            target_table = table
        elif mode.lower() == "drop_write":
            preAction = (str(preQry) + ';' if preQry is not None else '') + f"drop table if exists {table};"
            postAction = postQry
            target_table = table
        elif mode.lower() == "upsert":
            if (PrimaryColumns is None or
                    (not isinstance(PrimaryColumns, list) and not isinstance(PrimaryColumns, str)) or
                    (isinstance(PrimaryColumns, str) and str(PrimaryColumns).strip() == '') or
                    (isinstance(PrimaryColumns, list) and len(PrimaryColumns) == 0)):
                logs.warning("Primary Key not found. Getting it from TableMaster")
                JsonPath = Config.get('Environment', 's3.table.master.path')
                table_details = JobUtils.getTableDetails(glueContext, JsonPath, source, schema, table_name, mode='glue')
                if ((isinstance(table_details["PrimaryColumns"], list) and
                     len(table_details["PrimaryColumns"]) == 0) or
                        (table_details["PrimaryColumns"] is None)
                ):
                    msg1 = f"Primary Key can not be Null with Upsert mode. Either pass primary colums as a Input or " \
                           f"defined in TableMaster.json file"
                    logs.error(msg1)
                    raise ValueError(msg1)
                else:
                    PrimaryColumns = table_details["PrimaryColumns"]
                dbObj = cf.getDbClass(dbEngine='redshift', secret_name=secret_name)
                preAction, target_table = dbObj.getUpsertQry(table=table, batchId=batchId, PKCols=PrimaryColumns)
                preAction = (str(preQry) + ';' if preQry is not None else '') + preAction
                postAction = (str(
                    postQry) + ';' if postQry is not None else '') + f"drop table if exists {target_table};"
        elif mode.strip().lower() in ["append"]:
            preAction = preQry
            postAction = postQry
            target_table = table
        else:
            msg = f"Input write mode {mode} is invalid."
            logs.error(msg)
            raise ValueError(msg)
        try:
            conn_options = {"dbtable": target_table, "database": secret['dbname']}
            if preAction is not None:
                conn_options['preactions'] = preAction

            if postAction is not None:
                conn_options['postactions'] = postAction

            datasource0 = DynamicFrame.fromDF(df, glueContext, "datasource0")
            glueContext.write_dynamic_frame.from_jdbc_conf(frame=datasource0,
                                                           catalog_connection=glueConnectionName,
                                                           connection_options=conn_options,
                                                           redshift_tmp_dir=tempPath)
            return "Success"
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"

    # Method to write data into RDS (Postgres). By default it append data, We can pass Mode as Overwrite for truncate
    # and write. The option truncate -> true is only applicable when we overwrite data. If it is true then it will
    # truncate table and write new data and if it is false then it will drop table and create new table with new records.
    # Possible Mode value are "append"(default), "truncate_write", "drop_write"
    @staticmethod
    def writeUsingJDBC(spark, Config, df, source, schema, table_name, secret_name,
                       mode="append", Options=None, region_name='ap-south-1', PrimaryColumns=None):
        """
        Write Data into relational Database table through spark JDBC connection.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input dataframe.
        :param source: Source defined in TableMaster for input table to get all table level detail.
        :param schema: target table schema name.
        :param table_name: target table name.
        :param secret_name: AWS Secret manager name to get database credentials.
        :param mode: Write mode, Possible values are "append", "truncate_write", "drop_write", "upsert",
        "ignore", "error", "overwrite". [default -'append'].
        :param Options: Additional Spark JDBC Options[default - None]
        :param PrimaryColumns: Redshift table Primary Columns. Require for Upsert mode only. [default -None].
        :param region_name:  AWS Secret manager region name. [default - 'ap-south-1']

        :return status ['Success'|'Failed']
        """
        batchId = str(F.EpochTime())
        InputMode = mode
        logs.info(f"Input mode {InputMode} enabled.")
        try:
            secret1 = Sr.getSecret(secret_name, region_name=region_name)
            if 'engine' not in secret1.keys():
                engineFound = False
                Engine = None
                if Config.has_section('Environment'):
                    if Config.has_option('Environment', 'default.database.engine'):
                        Engine = Config.get('Environment', 'default.database.engine')
                        engineFound = True
                if not engineFound:
                    engMsg = f"database Engine type not found in secrets. Either defined it in Secret or " \
                             f"else enable the properties 'default.database.engine' in 'Environment' Section " \
                             f"of Config.properties file. " \
                             f"Possible Engine types are postgres, redshift, mysql and oracle."
                    logs.error(engMsg)
                    raise ValueError(engMsg)
            else:
                Engine = secret1['engine']

            if Engine.lower() == 'redshift':
                logs.error("For Redshift use 'writeIntoRedshift' method instead 'writeUsingJDBC'.")
            secret, Properties = F.getProperties(secret1, engine=Engine)
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"
        try:
            table = str(schema) + str(".") + str(table_name)
            target_table = table
            upsert_mode = False
            truncate = "true"
            if mode.lower() == "truncate_write":
                mode = "overwrite"
                truncate = "true"
                target_table = table
            elif mode.lower() == "drop_write":
                mode = "overwrite"
                truncate = "false"
                target_table = table
            elif mode.lower() == "upsert":
                upsert_mode = True
                target_table = f'{table}_{batchId}'
                if (PrimaryColumns is None or
                        (not isinstance(PrimaryColumns, list) and not isinstance(PrimaryColumns, str)) or
                        (isinstance(PrimaryColumns, str) and str(PrimaryColumns).strip() == '') or
                        (isinstance(PrimaryColumns, list) and len(PrimaryColumns) == 0)):
                    logs.warning("Primary Key not found. Getting it from TableMaster")
                    JsonPath = Config.get('Environment', 's3.table.master.path')
                    table_details = JobUtils.getTableDetails(spark, JsonPath, source, schema, table_name, mode='spark')
                    if ((isinstance(table_details["PrimaryColumns"], list) and
                         len(table_details["PrimaryColumns"]) == 0) or
                            (table_details["PrimaryColumns"] is None)
                    ):
                        msg1 = f"Primary Key can not be Null with Upsert mode. Either pass primary colums as a Input or " \
                               f"defined in TableMaster.json file"
                        logs.error(msg1)
                        raise ValueError(msg1)
                    else:
                        PrimaryColumns = table_details["PrimaryColumns"]
                    mode = "overwrite"
            elif mode.strip().lower() not in ["append", "ignore", "error", "overwrite"]:
                msg = f"Input write mode {mode} is invalid."
                logs.error(msg)
                raise ValueError(msg)

            logs.info(f"::::Writing data into Table {target_table} with Batch Id {batchId}")
            logs.info(f"{InputMode} is Enabled")
            default_properties = {"url": secret['url'], "dbtable": target_table,
                                  "numPartitions": 10, "batchsize": 10000, "truncate": truncate}
            if Options is not None:
                Prop = dict(list(default_properties.items()) + list(Properties.items()) + list(Options.items()))
            else:
                Prop = dict(list(default_properties.items()) + list(Properties.items()))
            df.write.format("jdbc").mode(mode.strip().lower()).options(**Prop).save()
            if upsert_mode:
                dbObj = cf.getDbClass(dbEngine=Engine, secret_name=secret_name)
                res = dbObj.UpsertData(table=table, batchId=batchId, PKCols=PrimaryColumns)
                return res
            else:
                return 'Success'
        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed"

    # Method to read manually State maintained other than Job bookmark. It will read last process state and return state
    # along with Column Name and Flag. If State not found for table then it might be first time load or Full Load table,
    # in that case Flag will be True.
    @staticmethod
    def getPreviousStates(spark: SparkSession, Config, JobName, Source, Schema, Table):
        """
        Read previous state of job for a particular source, schema and table. If state not set then full load flag will
        be True otherwise it will be False. If it return Full laod as True then use input table dataframe as it is
        otherwise filter the records as 'df.filter(WColumn) > edl_state'.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param JobName: Job Name.
        :param Source: Source defined in TableMaster for input table to get all table level detail.
        :param Schema: Table schema name(as per Table Master json).
        :param Table: table name.

        :return full load flag, Watermark Column Name, Watermark last value set
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'S3.table.state.path'):
                Path = Config.get('Environment', 'S3.table.state.path')
                msg1 = ""
            else:
                Path = None
                msg1 = '''The state path not found. Properties 'S3.table.state.path' of Section 'Environment' 
                           is either not set or blank. Please set S3 path to store job states in Properties file.'''
                logs.error(msg1)

            if Config.has_option('Environment', 's3.table.master.path'):
                JsonPath = Config.get('Environment', 's3.table.master.path')
                msg2 = ""
            else:
                JsonPath = None
                msg2 = '''The Table Master path not found. Properties 's3.table.master.path' of Section 'Environment' 
                           is  either not set or blank. Please set S3 path of table master json file in Properties file.'''
                logs.error(msg2)

            msg = msg1 + " " + msg2

            if (JsonPath is None) or (Path is None):
                raise ValueError(msg)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)

        if F.s3_Path_Exists(Path):
            stateDF = spark.read.parquet(Path).filter((col("Source") == lit(Source)) &
                                                      (trim(upper(col("JobName"))) == upper(lit(JobName))) &
                                                      ((col("Schema") == lit(Schema)) | col("Schema").isNull()) &
                                                      (col("Table") == lit(Table))
                                                      )

            if stateDF.count() > 0:
                JsonDF = spark.read.option("multiLine", "true").json(JsonPath) \
                    .filter((col("Source") == lit(Source)) &
                            (col("Schema") == lit(Schema)) &
                            (trim(col("Table")) == lit(Table)) &
                            (trim(col("StateColumn")) != ""))

                if JsonDF.count() > 0:
                    WColumn = JsonDF.select(col("StateColumn")).collect()[0][0]
                    edl_state = stateDF.agg(max(col("Watermark"))).collect()[0][0]
                    FullLoad = False
                else:
                    WColumn = "edl_created_at"
                    edl_state = stateDF.agg(max(col("edl_created_at"))).collect()[0][0]
                    FullLoad = False
            else:
                edl_state = 0
                WColumn = ""
                FullLoad = True
        else:
            edl_state = 0
            WColumn = ""
            FullLoad = True
        return (FullLoad, WColumn, edl_state)

    # Method to return State Dataframe for the input final dataframe and Table.
    @staticmethod
    def getCurrentStates(spark, Config, df, JobName, Source, Schema, Table):
        """
        Write current job state into configure state path.
        :param spark: spark Session.
        :param Config: Config object of properties file.
        :param df: Input table dataframe (after read data).
        :param JobName: Job Name.
        :param Source: Source defined in TableMaster for input table to get all table level detail.
        :param Schema: Table schema name(as per Table Master json).
        :param Table: table name.

        :return current states dataframe
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 's3.table.master.path'):
                JsonPath = Config.get('Environment', 's3.table.master.path')
                msg = ""
            else:
                JsonPath = None
                msg = '''The Table Master path not found. Properties 's3.table.master.path' of Section 'Environment' 
                             is  either not set or blank. Please set S3 path of table master json file in Properties file.'''
                logs.error(msg)
            if JsonPath is None:
                raise ValueError(msg)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)
        JobRun = F.TimeNow()
        StateSchema = StructType([StructField('Source', StringType()),
                                  StructField('Schema', StringType()),
                                  StructField('Table', StringType()),
                                  StructField('JobRunTime', StringType()),
                                  StructField('edl_created_at', LongType()),
                                  StructField('Watermark', StringType()),
                                  StructField('JobName', StringType())])
        JsonDF = spark.read.option("multiLine", "true").json(JsonPath) \
            .filter((col("Schema") == lit(Schema)) & (trim(col("Table")) == lit(Table))) \
            .filter(trim(col("StateColumn")) != "")

        if JsonDF.count() > 0:
            WColumn = JsonDF.select(col("StateColumn")).collect()[0][0]
            MaxValue = df.agg(max(col("edl_created_at")), max(col(WColumn))).collect()[0]
            edl_created_at = int(MaxValue[0])
            Watermark = str(MaxValue[1])
            logs.info(
                ":::Debug Table {}, WColumn {}, edl_created_at {}, Watermark {}".format(Table, WColumn, edl_created_at,
                                                                                        Watermark))
            State = [(Source, Schema, Table, JobRun, edl_created_at, Watermark, str(JobName).upper())]
        else:
            edl_created_at = df.agg(max(col("edl_created_at"))).collect()[0][0]
            State = [(Source, Schema, Table, JobRun, edl_created_at, '2000-01-01 00:00:00.000', str(JobName).upper())]

        stateDF = spark.createDataFrame(data=State, schema=StateSchema) \
            .withColumn("Watermark", col("Watermark").cast("Timestamp"))

        return stateDF

    # Method to append State data with into S3 Bucket.
    @staticmethod
    def writeJobStates(Config, df):
        """
        Write current job states into configure s3 state path.
        :param Config: Config object of properties file.
        :param df: Input state dataframe.The dataframe that return from getCurrentStates method.

        :return status ['Success'|'Failed']
        """
        if Config.has_section('Environment'):
            if Config.has_option('Environment', 'S3.table.state.path'):
                StatePath = Config.get('Environment', 'S3.table.state.path')
                msg = ""
            else:
                StatePath = None
                msg = '''The state path not found. Properties 'S3.table.state.path' of Section 'Environment' 
                           is either not set or blank. Please set S3 path to store job states in Properties file.'''
                logs.error(msg)
            if StatePath is None:
                raise ValueError(msg)
        else:
            msg = "'Environment' section is not found in Properties file."
            raise ValueError(msg)

        logs.info(":::Writing Job state to the path {}".format(StatePath))
        try:
            logs.info("Current Job run states is ..")
            df.show(truncate=False)
            df.write.partitionBy("Source", "JobName", "Schema", "Table").mode("append").parquet(StatePath)
            return 'Success'
        except Exception as e:
            logs.error('Error occur while write state into S3.')
            logs.error(e)
            return 'Failed'

    # Method to Write data into DynamoDB Table. It is recommended to keep target Dynamodb Tables at On-demand mode to
    # get good write performance.
    @staticmethod
    def writeIntoDynamoDb(GlueContext, df, Table):
        """
        Write data into DynamoDB table using Glue Context.
        :param GlueContext: Glue Context.
        :param df: Input dataframe.
        :param Table: DynamoDb table name.

        :return status ['Success'|'Failed']
        """
        logger = GlueContext.get_logger()
        try:
            dydf = DynamicFrame.fromDF(df, GlueContext, "dydf")
            logger.info("::::Writing Dataframe data into Dynamodb table {}".format(Table))

            GlueContext.write_dynamic_frame.from_options(frame=dydf,
                                                         connection_type="dynamodb",
                                                         connection_options={"tableName": Table}
                                                         )
            return "Success"
        except Exception as e:
            logger.error(e)
            return ("Failed -" + str(e))


    @staticmethod
    def readDfFromCsv(spark,path):
        logs.info(":::Reading csv from path {}".format(path))
        df = spark.read.format("csv").option("mode", "permissive").option("header", "true").load(path)
        return df

    @staticmethod
    def readDfFromExcel(path,sheet_name):
        import pandas as pd
        logs.info(":::Reading excel from path {}".format(path))
        df = pd.read_excel(path,sheet_name = sheet_name)
        df = df.applymap(str)
        return df

    @staticmethod
    def writeDfToS3Parquet(file_name, df, sink_path, op_yr_mnth, mode="overwrite"):
        f_sink_path = sink_path + "/" + op_yr_mnth + "/"
        f_sink_path= f_sink_path.replace("//", "/")
        f_sink_path = f_sink_path.replace(":/", "://")
        logs.info(f":::Writing {file_name} to - {f_sink_path}")

        df= df.withColumn("btch_rn_dt", to_timestamp(current_timestamp(),"MM-dd-yyyy HH:mm:ss")). \
            withColumn("year_mnth", lit(op_yr_mnth))
 
        df.write.mode(mode).parquet(f_sink_path)

        logs.info(f"::: Data has written successfully to target path {f_sink_path}")
        return df

    @staticmethod
    def read_yaml(yaml_path):
        import boto3
        import yaml

        bucket = yaml_path.split("/")[2]
        key = yaml_path.split("/", 3)[3]

        s3_client = boto3.client('s3')
        response = s3_client.get_object(Bucket=bucket, Key=key)
        yaml_dict = yaml.safe_load(response["Body"])

        return yaml_dict


    @staticmethod
    def readDfFromHudiParquet(spark, ip_file_path):
        logs.info(":::Reading parquet from path {}".format(ip_file_path))
        try:
            print("Reading from Apache Hudi")
            df = spark.read.format("org.apache.hudi").load(ip_file_path)
            return df  

        except Exception as e:
            print("Reading from Parquet")
            df = spark.read.parquet(ip_file_path)
            return df  


    @staticmethod
    def getDate(lag,date_str,experience_study_period):
        from datetime import datetime,timedelta
        import dateutil.relativedelta
        date_object = datetime.strptime(date_str, '%Y-%m-%d').date()
        exposure_end_date = (date_object - dateutil.relativedelta.relativedelta(months=lag))+  dateutil.relativedelta.relativedelta(months=1, day=1, days=-1)
        exposure_start_date = (exposure_end_date - dateutil.relativedelta.relativedelta(months=experience_study_period-1)).replace(day=1)
        print("exposure_start_date : ",exposure_start_date)
        print("exposure_end_date : ",exposure_end_date)
        return exposure_start_date,exposure_end_date
    



    @staticmethod
    def getTableList(spark, path):
        logs.info(":::: Reading from Json - {}".format(path))
        AllTblDF = spark.read.option("multiLine", "true").json(path)
        finalDF = AllTblDF.withColumn("SchemaTableFullload",
                                      concat(trim(col("Target")), lit(","), trim(col("Source")),
                                             lit(","), trim(col("Sk")),
                                             lit(","), trim(col("JobId")),
                                             lit(","), trim(col("TargetTable")),
                                             lit(","), trim(col("BaseTable")),
                                             lit(","), trim(col("Write")))) \
            .withColumn("ExecutionOrder", col("ExecutionOrder").cast("Int"))\
            .select(col("SchemaTableFullload"), col("ExecutionOrder")).distinct().orderBy(col("ExecutionOrder"))
        logs.info(finalDF.show())
        if finalDF.count() == 0:
            return []
        else:
            return [x.SchemaTableFullload for x in finalDF.select('SchemaTableFullload').collect()]
        


    @staticmethod
    def GetJsonDf(spark, JsonPath):
        logs.info(":::: Making Json DF from - {}".format(JsonPath))
        JsonDF = spark.read.option("multiLine", "true").json(JsonPath).withColumn("Order", col("Order").cast("Int"))
        return JsonDF
    

    @staticmethod
    def getPrimaryColList(spark, JsonDataDf, source, table):
        df1 = JsonDataDf.filter(
            (upper(col("Source")) == upper(lit(source))) &
            (upper(col("JobId")) == upper(lit(table))) &
            (trim(upper(col("View"))) == upper(lit("FinalView"))) &
            (~(trim(col("Pk")) == lit(""))) )

        if len(df1.head(1)) == 0:
            return ""
        
        PriCols = df1.select("Pk").collect()[0][0]
        return PriCols.lower()
    


    @staticmethod
    def writeHudiDf(input_df, pk, jobName, tableName, sk, pathToFolder):

        hudi_options = {
            # ---------------DATA SOURCE WRITE CONFIGS---------------#
            "hoodie.table.name": tableName,
            "hoodie.datasource.write.recordkey.field": pk,
            "hoodie.datasource.write.precombine.field": "btch_rn_dt",
            # "hoodie.datasource.write.partitionpath.field": "year,month,day",
            # "hoodie.datasource.write.hive_style_partitioning": "true",
            # "hoodie.datasource.write.keygenerator.class": "org.apache.hudi.keygen.ComplexKeyGenerator",
            "hoodie.bloom.index.update.partition.path": "true",
            # "hoodie.datasource.hive_sync.partition_fields":"year, month, day",
            "hoodie.upsert.shuffle.parallelism": 1,
            "hoodie.insert.shuffle.parallelism": 1,
            "hoodie.consistency.check.enabled": True,
            "hoodie.index.type": "GLOBAL_BLOOM",
            "hoodie.index.bloom.num_entries": 60000,
            "hoodie.index.bloom.fpp": 0.000000001,
            "hoodie.cleaner.commits.retained": 2,
        }
        incrementalConfig = {'hoodie.upsert.shuffle.parallelism': 68,
                             'hoodie.datasource.write.operation': 'upsert',
                             'hoodie.cleaner.policy': 'KEEP_LATEST_COMMITS',
                             'hoodie.cleaner.commits.retained': 10
                             }
        initLoadConfig = {
            'hoodie.bulkinsert.shuffle.parallelism': 68,
            'hoodie.datasource.write.operation': 'bulk_insert'
        }
        combinedConfinit = {**hudi_options, **initLoadConfig}

        runDate = current_timestamp()

        try:
            windowSpec3 = Window.orderBy(lit("1"))
            audit_df = input_df.withColumn("edl_crtd_by", lit(jobName)) \
                                .withColumn("btch_rn_dt", lit(runDate))

            final_df = audit_df.withColumn("id_temp", row_number().over(windowSpec3)) \
                                .withColumn(sk, col("id_temp").cast("long")).drop("id_temp")

            final = F.toLowerCaseColumnName(final_df)
            final.createOrReplaceTempView(tableName)

            logs.info(":::: Writing df to path - {}".format(pathToFolder))
            final.createOrReplaceTempView(tableName)
           
            final.write.format("hudi") \
                    .options(**combinedConfinit) \
                    .mode("overwrite") \
                    .save(pathToFolder)

            return "Success"

        except Exception as e:
            logs.error(e, exc_info=True)
            return "Failed -" + str(e)
        


    @staticmethod
    def CreateView(spark,dd):
        for x in dd:
            View = x["View"]
            Qry = x["Sql"]
            spark.sql(Qry).createOrReplaceTempView(View)

    @staticmethod
    def ExecuteSQLStatements(spark, JsonDF, Key):
        JsonDF1 = JsonDF.filter(upper(col("JobId")) == lit(Key))
        ViewSql = list(map(lambda r: r.asDict(), JsonDF1.select(col("View"), col("Sql")).orderBy(col("Order")).collect()))
        print(ViewSql)
        JobUtils.CreateView(spark, ViewSql)
        df = spark.sql("SELECT * FROM FinalView")
        return df
    
    @staticmethod
    def readFromRDS(spark: SparkSession, schema, tablename):
        table = str(schema) + str(".") + str(tablename)
        (url, Properties, host, port, db) = con.getConnection("RDS")
        df = spark.read.jdbc(url=url, table=table, properties=Properties)
        return df
    
    @staticmethod
    def readStandardTableData(spark: SparkSession, Config, Source: str, Schema: str, Table: str):
        SrcDirProp = str(Source).lower() + str('.standard.src.path')
        FilePath = Config.get("DATAMART_JOB_INPUT_PARAMS", SrcDirProp)
        logs.info("::::File path for Table {} is {}".format(Table, FilePath))
        df = spark.read.parquet(FilePath)
        return df
    
    @staticmethod
    def readDataMartTableData(spark: SparkSession, Config, Source: str, Schema: str, Table: str):
        SrcDirProp = str(Source).lower() + str('.datamart_temp.src.path')
        FilePath = Config.get("DATAMART_JOB_INPUT_PARAMS", SrcDirProp)
        logs.info("::::File path for Table {} is {}".format(Table, FilePath))
        df = spark.read.parquet(FilePath)
        return df
    

    @staticmethod
    def readTransformedTableData(spark: SparkSession, Config, Source: str, Schema: str, Table: str):
        SrcDirProp = str(Source).upper() + str('.transformed.src.path')
        FilePath = Config.get("DATAMART_JOB_INPUT_PARAMS", SrcDirProp)
        logs.info("::::File path for Table {} is {}".format(Table, FilePath))
        df = spark.read.parquet(FilePath)
        return df
    


    @staticmethod
    def writeIntoRDS(df, schema, tablename, mode="append"):
        (url, Properties, host, port, db) = con.getConnection("RDS")
        table = str(schema) + str(".") + str(tablename)
        logs.info("::::Table Name is {}".format(table))
        if mode.lower() == "append":
            df.write.jdbc(url, table, "append", Properties)
        elif mode.lower() == "truncate_write":
            df.write.option("truncate", "true").jdbc(url, table, "overwrite", Properties)
        elif mode.lower() == "drop_write":
            df.write.option("truncate", "false").jdbc(url, table, "overwrite", Properties)
        else:
            log.error("::::Invalid Write Mode found - {}".format(mode))
        return "Success"