from com.maxlifeinsurance.framework.utils.ConfigUtils import ConfigUtils
from com.maxlifeinsurance.framework.utils.SecretUtils import SecretUtils as Sr
import logging as logs


class ConnectionUtils():
    @staticmethod
    def getConnection(source):
        logs.basicConfig()
        logs.getLogger().setLevel(logs.INFO)
        Con = ConfigUtils().getConfig()
        env = Con.get('Environment', 'server.environment')
        region_name = Con.get('Environment', 'server.region.name')
        configProp = "secret." + str(source).lower() + ".name"
        secret_name = Con.get('SECRET', configProp)
        if secret_name.strip() != "":
            secret = Sr.getSecret(secret_name, region_name)
            if source.upper() == "RDS":
                dbuser = secret['username']
                dbpassword = secret['password']
                dbhost = secret['host']
                dbport = int(secret['port'])
                dbname = "mli-crisp-prod-data-mart"
                dbdriver = "org.postgresql.Driver"
                url = "jdbc:postgresql://{}:{}/{}".format(dbhost, str(dbport), dbname)
                Prop = dict(driver=dbdriver, user=dbuser, password=dbpassword)
            else:
                logs.warning("::::Connection is not defined for the Source {} in Environment {}".format(source, env))
                dbhost = ""
                dbport = 0
                dbname = ""
                url = ""
                Prop = dict()
            return (url, Prop, dbhost, dbport, dbname)
        else:
            logs.error("::::Secret Name missing in Config file for the Source {}".format(source))
            return ("", dict(), "", 0, "")