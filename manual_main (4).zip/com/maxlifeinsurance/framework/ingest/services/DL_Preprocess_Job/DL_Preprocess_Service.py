from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as logs
from datetime import date


class DL_Preprocess_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def DL_Preprocess_Ingest(self, file_name):
        try:
            crrnt_dt = date.today()
            if crrnt_dt.month == 1:
                lm_yr = crrnt_dt.year-1
                lm_mnth = 12
            else:
                lm_yr = crrnt_dt.year
                lm_mnth = crrnt_dt.month-1
                
            if lm_mnth<10:
                lm_mnth = "0"+str(lm_mnth)

            lm_yr_mnth = str(lm_yr) + str(lm_mnth)


            src_path = self.Config.get('DL_PREPROCEES_JOB_INPUT_PARAMS', f"dl.{file_name}.src.path")
            sink_path = self.Config.get('DL_PREPROCEES_JOB_OUTPUT_PARAMS', f"dl.{file_name}.tgt.path")


            src_df = Jb.readDfFromHudiParquet(self.spark, src_path)
            
            fdf = Jb.writeDfToS3Parquet(file_name, src_df, sink_path, lm_yr_mnth, "overwrite")

            src_cnt = src_df.count()
            raw_cnt = fdf.count()
            if src_cnt == raw_cnt:
                logs.info(f"src_cnt : {src_cnt}  , raw_cnt :{raw_cnt}")
                logs.info(f"For {file_name} validation successfully completed")
                return "SUCCESS"
            else:
                logs.info(f"src_cnt : {src_cnt}  , raw_cnt :{raw_cnt}")
                logs.error(f"For {file_name} validation failed")
                return "FAILED"

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))
        
