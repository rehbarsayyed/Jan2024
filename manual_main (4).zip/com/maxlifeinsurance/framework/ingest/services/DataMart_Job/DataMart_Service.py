from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType
import json
import boto3
import re
from datetime import date


class DataMart_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def DataMart_Run(self):
        try:
            jsonPath = self.Config.get('DATAMART_JOB_INPUT_PARAMS', 'datamart_master_path')
            tableList = Jb.getTableList(self.spark, jsonPath)
            log.info("::::Final Tables List are {}".format(tableList))

            JsonDataDf = Jb.GetJsonDf(self.spark, jsonPath)
            runDate = current_timestamp()

            for table in tableList:
                Source = str(table.split(",")[1]).strip(' ').lower()
                tableName = str(table.split(",")[3]).strip(' ').lower()
                baseTable = str(table.split(",")[5]).strip(' ').upper()
                write = str(table.split(",")[6]).strip(' ').upper()
                schema = "ae_crisp_report"

                std_list = ["plcy_cstmr", "cstmr_cmmnctn", "lkp_pincode_gcl", "cstmr_prsnl", "plcy_cvg",
                            "lkp_ibnr_ind", "lkp_ibnr_grp", "lkp_ibnr_ind_prot", "lkp_ibnr_ind_non_prot", "lkp_pln_cd_mppng_w",
                            "plcy_cvg", "std_office_dtl", "plcy_cstmr", "cstmr_prsnl", "cstmr_cmmnctn", "lkp_itddrilldown_ind", 
                            "mortality_gcl"]

                dm_list = ["ytd_agncy", "std_ytd_plcy_fct", "itd_agncy", "std_itd_plcy_fct"]
                if baseTable == "Y":
                    if Source == "rds":
                        tblDF = Jb.readFromRDS(self.spark, schema, tableName)
                        tblDF.createOrReplaceTempView(tableName)
                        
                    elif Source in std_list:
                        tblDF = Jb.readStandardTableData(self.spark, self.Config, Source, "", tableName)
                        tblDF.createOrReplaceTempView(tableName)

                    elif Source in dm_list:
                        tblDF = Jb.readDataMartTableData(self.spark, self.Config, Source, "", tableName)
                        tblDF.createOrReplaceTempView(tableName)
                    else:
                        tblDF1 = Jb.readTransformedTableData(self.spark, self.Config, Source, "", tableName)
                        tblDF1.createOrReplaceTempView(tableName)


                sqlDF = Jb.ExecuteSQLStatements(self.spark, JsonDataDf, tableName.upper())\
                            .withColumn("rcrd_ld_dt", lit(runDate)) \
                            .withColumn("effctv_strt_dt", lit(runDate)) \
                            .withColumn("effctv_end_dt", to_timestamp(lit("3099-01-01 0:00:00.000")))
                
                finalDF1 = sqlDF


                if write == "Y":
                    targetTableName = str(table.split(",")[4]).strip(' ').lower()
                    if targetTableName.startswith("plcy_itd_fct") or targetTableName.startswith("plcy_ytd_fct") :
                        target_path = self.Config.get("DATAMART_JOB_OUTPUT_PARAMS", f"{targetTableName}.datamart_temp.tgt.path")
                        log.info(f" writing df {targetTableName} to  {target_path}")
                        finalDF1.repartition(500).write.option("maxRecordsPerFile", 100000).mode("overwrite").parquet(target_path)
                        res = "SUCCESS"
                    else:
                        res = Jb.writeIntoRDS(finalDF1, schema, targetTableName, mode="append")

                    if res.upper() == "SUCCESS":
                        log.info(":::: Data written for table {} successfully".format(tableName))
                        finalCount = finalDF1.count()
                        log.info(":::: count is {} for table {}".format(finalCount, tableName))
                    else:
                        return "Failed - Failed to write data to table {}".format((tableName))
                else:
                    log.info(":::: No data to write for table {}".format(tableName))


            return "SUCCESS"

        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e))