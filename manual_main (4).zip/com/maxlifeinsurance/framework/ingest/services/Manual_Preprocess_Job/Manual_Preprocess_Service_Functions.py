from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as logs
from pyspark.sql.types import StructType, StructField, StringType, LongType
from pathlib import Path
import os.path
from os.path import exists as file_exists

class Manual_Preprocess_Service_Functions(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext
        

    def checkcols(self, df, file_name, config_dict):
        try:
            logs.info("Checking file columns with yaml")

            file_cols = df.columns
            file_cols = [x.upper() for x in file_cols]
            
            clmn_nt_prsnt = []
            for x in config_dict["manual_table"][file_name]["attribute"]["input"]:
                yaml_col = str(x["inputColName"]).upper().strip()
                if yaml_col not in file_cols:
                    clmn_nt_prsnt.append(yaml_col)

            if len(clmn_nt_prsnt)>0:
                raise Exception(f"Following columns are not present in input file - {clmn_nt_prsnt}")
            else:
                print(f"All columns are present in Input {file_name} file")
                return df

        except Exception as e:
            logs.error(f"Unable to get the column {clmn_nt_prsnt} , please check input file and yaml file")
            logs.error(e, exc_info=True)
            return "Exception -" + str(e)


    def format_df_date(self, df, file_name, config_dict):
        try:
            logs.info("Changing Data type of df")
            for x in config_dict["manual_table"][file_name]["attribute"]:
                if x.upper().strip() == "OUTPUT":
                    for i in config_dict["manual_table"][file_name]["attribute"][x]:
                        col_name = str(i["outputColName"]).upper().strip()
                        ip_dt_format = str(i["ip_format"])
                        df = df.withColumn(col_name, to_timestamp(col_name, ip_dt_format))
                        
            return df

        except Exception as e:
            logs.error(e, exc_info=True)
            return "Exception -" + str(e)


    def rmv_spl_ch_cols(self, df):
        import re
        import pyspark.sql.functions as PF
        logs.info(":::Renaming column name of dataframe")
        df = self.spark.createDataFrame(df)
        df = df.toDF(*(c.replace('.', '_') for c in df.columns))
        df = df.select([PF.col(col).alias(re.sub("[^0-9a-zA-Z$]+","_",col)) for col in df.columns])
        df = df.select([PF.col(col).alias(re.sub("_$|^_", "", col)) for col in df.columns])
        return df


    def read_file(self, src_path):
        print("Reading from - ", str(src_path))

        emp_RDD = self.spark.sparkContext.emptyRDD()
        columns = StructType([])
        input_df = self.spark.createDataFrame(data = emp_RDD,schema = columns)

        file_prefix=Path(src_path).name
        file_extension = os.path.splitext(src_path)[1]

        print("File extension is : ", file_extension)

        if file_extension == ".csv":
            input_df = Jb.readDfFromCsv(self.spark, src_path)

        elif file_extension == ".xlsx":
            if file_prefix.startswith("Analysis"):
                logs.info("Calling Analysis file condition")

                excel_df = Jb.readDfFromExcel(src_path,sheet_name = "Member")
                new_header = excel_df.iloc[3]
                df = excel_df[4:]
                df.columns = new_header
                input_df = self.rmv_spl_ch_cols(df)
                
            else:
                df = Jb.readDfFromExcel(src_path,sheet_name = "Sheet1")
                input_df = self.rmv_spl_ch_cols(df)

        else:
                logs.error("Invalid file format with ",file_extension)

        return input_df
        

    def dataValidation(self, file_name, src_df, fdf):
        src_cnt = src_df.count()
        raw_cnt = fdf.count()
        if src_cnt == raw_cnt:
            logs.info(f"src_cnt : {src_cnt}  , raw_cnt :{raw_cnt}")
            logs.info(f"For {file_name} validation successfully completed")
            return "SUCCESS"
        else:
            logs.info(f"src_cnt : {src_cnt}  , raw_cnt :{raw_cnt}")
            logs.error(f"For {file_name} validation failed")
            return "FAILED"