from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from com.maxlifeinsurance.framework.ingest.services.Manual_Preprocess_Job.Manual_Preprocess_Service_Functions import Manual_Preprocess_Service_Functions
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType


class Manual_Preprocess_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def Manual_Preprocess_Business_Logic(self, file_name, op_yr_mnth, config_dict):
        try:
            src_path = self.Config.get('MANUAL_PREPROCEES_JOB_INPUT_PARAMS', f"manual.{file_name}.src.path")
            sink_path = self.Config.get('MANUAL_PREPROCEES_JOB_OUTPUT_PARAMS', f"manual.{file_name}.tgt.path")

            obj = Manual_Preprocess_Service_Functions(self.spark, self.glueContext, self.Config)

            src_df = obj.read_file(src_path)

            df = obj.checkcols(src_df, file_name, config_dict)

            df = obj.format_df_date(df, file_name, config_dict)

            fdf = Jb.writeDfToS3Parquet(file_name, df, sink_path, op_yr_mnth, "overwrite")

            res = obj.dataValidation(file_name, src_df, fdf)

            return res

        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e))
        
