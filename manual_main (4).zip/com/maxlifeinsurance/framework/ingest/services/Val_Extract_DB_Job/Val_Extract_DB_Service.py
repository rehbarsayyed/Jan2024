from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType
import pyspark.sql.functions as F
import json
import boto3
import re
from datetime import date


class Val_Extract_DB_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def Val_Extract_DB_Ingest(self):
        try:
            crrnt_dt = date.today()
            if crrnt_dt.month == 1:
                lm_yr = crrnt_dt.year-1
                lm_mnth = 12
            else:
                lm_yr = crrnt_dt.year
                lm_mnth = crrnt_dt.month-1
                
            if lm_mnth<10:
                lm_mnth = "0"+str(lm_mnth)
                
            conn_details = [
                {
                    "db_name" : "stag6900",
                    "db_table" : "REPORT247.VU_GMI_VAL",
                    "jdbc_str" : "jdbc:oracle:thin:@172.23.51.5:1875/stag6900",
                    "secret_name" : "mli-prod-crisp-val-extract",
                    "op_fldr_nm" : "gmi"
                },
                {
                    "db_name" : "stag6900",
                    "db_table" : "REPORT247.TBL_VAL_EXTRACT_HEALTHY",
                    "jdbc_str" : "jdbc:oracle:thin:@172.23.51.5:1875/stag6900",
                    "secret_name" : "mli-prod-crisp-val-extract",
                    "op_fldr_nm" : "health"
                },
                {
                    "db_name" : "stag6900",
                    "db_table" : "REPORT247.DW_VAL_EXTRACT_UL",
                    "jdbc_str" : "jdbc:oracle:thin:@172.23.51.5:1875/stag6900",
                    "secret_name" : "mli-prod-crisp-val-extract",
                    "op_fldr_nm" : "ul"
                },
                {
                    "db_name" : "stag6900",
                    "db_table" : "REPORT247.DW_VALUATION_EXTRACT",
                    "jdbc_str" : "jdbc:oracle:thin:@172.23.51.5:1875/stag6900",
                    "secret_name" : "mli-prod-crisp-val-extract",
                    "op_fldr_nm" : "trad"
                },
                {
                    "db_name" : "renoprod",
                    "db_table" : "VAL_EXTRACT_RENOVA_CURRENT",
                    "jdbc_str" : "jdbc:oracle:thin:@172.23.51.26:1875/renoprod",
                    "secret_name" : "mli-prod-crisp-renova",
                    "op_fldr_nm" : "renova"
                }
            ]

            for conn_dtl in conn_details:
                db_name = conn_dtl['db_name']
                db_table = conn_dtl['db_table']
                jdbc_str = conn_dtl['jdbc_str']
                SecretName= conn_dtl['secret_name']
                op_folder_nm = conn_dtl['op_fldr_nm']

                sc_manager_client = boto3.client('secretsmanager')
                response = sc_manager_client.get_secret_value(SecretId= SecretName)
                response['SecretString']
                SecretDict = json.loads(response['SecretString'])
                user=SecretDict['username']
                password = SecretDict['password']

                # Output Year + Month
                lm_yr_mnth = str(lm_yr) + str(lm_mnth)
                s3_sink_path = f"s3://mli-dl-prod-crisp/landing/val/{op_folder_nm}/{lm_yr_mnth}/"
                s3_sink_path= s3_sink_path.replace("//", "/")
                s3_sink_path = s3_sink_path.replace(":/", "://")

                print("db_name - ", db_name)
                print("db_table - ", db_table)
                print("op_folder_nm - ", op_folder_nm)
                print("Sink_Path - ", s3_sink_path)
            
                df_read = self.spark.read.format("jdbc").option("url",jdbc_str).option("driver","oracle.jdbc.driver.OracleDriver").\
                option("user",user).option("password",password).option("fetchsize","500000").option("batchsize","500000").option("dbtable",db_table).load()
            
                df_with_date=  (df_read.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","_",col)) for col in df_read.columns]).\
                withColumn("month", lit(lm_yr_mnth))). \
                withColumn("PLN_ID",col("PLAN_ID"))
            
                print(f"##################### table count is : {df_with_date.count()} ########")
                print (f"writing data to {s3_sink_path} ")
                df_with_date.write.option("header","true").partitionBy("plan_id").mode("overwrite").parquet(s3_sink_path)
                print("Writing success for - ", op_folder_nm)


            return "SUCCESS"

        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e))