import logging
import sys
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class CC(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_cc(self,src_data,src_stg_cncr_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            logging.info("Loading cc_claims file")

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            sdf = sdf.toDF(*(c.replace('.', '_') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            # lag = 1
            # experience_study_period = 12
            # exposure_start_date = "2021-05-01"
            # exposure_end_date = "2022-04-30"


            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_cc"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_cc"))

            print("CC date Str - ", date_str)
            print("CC lag period - ", lag)
            print("CC experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("CC exposure_date - ", exposure_date)
            print("CC exposure_start_date - ", exposure_start_date)
            print("CC exposure_end_date - ", exposure_end_date)

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("INFORCEDATE",to_date(col("INFORCEDATE"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofIntimationGO",to_date(col("DateofIntimationGO"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("CompleteDocsClarificationReceiveddate",to_date(col("CompleteDocsClarificationReceiveddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("InvestReportrecddate",to_date(col("InvestReportrecddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateProposalSigned",to_date(col("DateProposalSigned"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("PolicyIssueDate",to_date(col("PolicyIssueDate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_start_date",to_date(lit(exposure_start_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date(lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofDiagnosisorSurgery",to_date(col("DateofDiagnosisorSurgery"),"yyyy-MM-dd HH:mm:ss"))


            #Remove Non adm and Repudiation cases
            list_prod_codes_remove = ["Non Adm","Repudiation","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))

            # Keep Date of surgery only till investigation period
            dos=stage_exclude.filter(col("DateofDiagnosisorSurgery")<=col("exposure_end_date"))

            #Keep Cancer care products
            cc=dos.filter(upper(col("NatureofBasePolicy")).contains("CANCER"))

            #Keep Date of Death "NA" only
            dod=cc.filter(col("DateofDeath").isNull())


            final_df=dod.select("SNo","Stage","PolicyNo","FileRefNo","LifeInsured","DateofDiagnosisorSurgery","DateofDeath","DateofIntimationHO","ClaimAmountBASERIDER",
                                "RepudiationDateSettlementDate","DOB","CauseofDeath","CategoryofDeath","NatureofBasePolicy") \
                .withColumnRenamed("SNo","s_no") \
                .withColumnRenamed("Stage","stage") \
                .withColumnRenamed("PolicyNo","policy_no") \
                .withColumnRenamed("FileRefNo","file_ref_no") \
                .withColumnRenamed("LifeInsured","life_insured") \
                .withColumnRenamed("DateofDiagnosisorSurgery","date_of_diagnosis") \
                .withColumnRenamed("DateofDeath","date_of_death") \
                .withColumnRenamed("DateofIntimationHO","date_of_intimation") \
                .withColumnRenamed("ClaimAmountBASERIDER","amt_paid_involved") \
                .withColumnRenamed("RepudiationDateSettlementDate","settlement_date") \
                .withColumnRenamed("DOB","dob") \
                .withColumnRenamed("CauseofDeath","cause_of_death") \
                .withColumnRenamed("CategoryofDeath:","category_of_death") \
                .withColumnRenamed("NatureofBasePolicy","nature_of_base_policy")


            df_pol_output1 = src_stg_cncr_data
            df1=df_pol_output1
            sdf_claims_stage=spark.createDataFrame(df1)

            sdf_claims_stage = sdf_claims_stage.toDF(*(c.replace('.', '') for c in sdf_claims_stage.columns))
            sdf_claims_stage = sdf_claims_stage.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf_claims_stage.columns])
            sdf_claims_stage1=sdf_claims_stage.withColumnRenamed("PolicyNo","policy_no").withColumnRenamed("ClaimStage","stage_of_cancer")


            final_df_soc=sdf_claims_stage1.join(final_df,"policy_no","right")\
                .select("s_no","stage","policy_no","file_ref_no","life_insured","date_of_diagnosis","date_of_death","date_of_intimation",
                        "amt_paid_involved","settlement_date","dob","cause_of_death","CategoryofDeath","nature_of_base_policy","stage_of_cancer")\
                .toDF("s_no","stage","policy_no","file_ref_no","life_insured","date_of_diagnosis","date_of_death","date_of_intimation_ho",
                      "amt_paid__involved","settlement_date","dob","cause_of_death","Category_of_Death","nature_of_base_policy","stage_of_cancer")


            sink_path=sink_path+"claims_cc"
            logging.info(f"Writing final_df to {sink_path} ")
            final_df_soc.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f" Data has written successfully to path {sink_path} ")
            return "SUCCESS"
            
        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)