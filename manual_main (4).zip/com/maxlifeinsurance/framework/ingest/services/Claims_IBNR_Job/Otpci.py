import logging
import sys
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class Otcpi(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_otpci(self,src_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            logging.info("Loading claims_otpci file")

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)

            sdf = sdf.toDF(*(c.replace('.', '') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            # lag=1
            # experience_study_period = 12
            # exposure_start_date = "2021-04-01"
            # exposure_end_date = "2022-03-31"            

            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_otpci"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_otpci"))

            print("OTPCI date Str - ", date_str)
            print("OTPCI lag period - ", lag)
            print("OTPCI experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("OTPCI exposure_date - ", exposure_date)
            print("OTPCI exposure_start_date - ", exposure_start_date)
            print("OTPCI exposure_end_date - ", exposure_end_date)

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("INFORCEDATE",to_date(col("INFORCEDATE"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit("2021-09-30"), "yyyy-MM-dd")) \
                .withColumn("DateofIntimationGO",to_date(col("DateofIntimationGO"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("CompleteDocsClarificationReceiveddate",to_date(col("CompleteDocsClarificationReceiveddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("InvestReportrecddate",to_date(col("InvestReportrecddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateProposalSigned",to_date(col("DateProposalSigned"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("PolicyIssueDate",to_date(col("PolicyIssueDate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_start_date",to_date(lit(exposure_start_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date( lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofDiagnosisorSurgery",to_date(col("DateofDiagnosisorSurgery"),"yyyy-MM-dd HH:mm:ss"))


            #Remove Non adm and Repudiation cases
            list_prod_codes_remove = ["Non Adm","Repudiation","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))


            # Date of diagnosis till investgation period only
            do_diagnosis=stage_exclude.filter((col("DateofDiagnosisorSurgery")<=col("exposure_end_date")))

            # Date of death "NA" only
            dod=do_diagnosis.filter(col("DateofDeath").isNull())

            # Waiver of premium 0 and blank cases only
            # wop_li=[0,'',"-"]
            # wop_exclude=dod.filter(dod['WaiverofPremiumPayorRider'].isin(wop_li))
            wop_exclude=dod.filter((col("WaiverofPremiumPayorRider")==0) | (col("WaiverofPremiumPayorRider")=='0') | (col("WaiverofPremiumPayorRider")=='') | (col("WaiverofPremiumPayorRider")=='-'))\

            # Nature of base policy Online term plan only
            nobp=wop_exclude.filter(upper(col("NatureofBasePolicy")).contains("ONLINE TERM PLAN"))

            # Filter only on cases where CI amount is non-zero
            cia=nobp.filter(col("CriticalIllnessAmount")!=0)


            final_df=cia.select("SNo","Stage","PolicyNo","FileRefNo","LifeInsured","MedNonMedProposalStage","DateofDiagnosisorSurgery",
                                "DateofIntimationHO","ClaimAmountBASERIDER","RepudiationDateSettlementDate","DOB") \
                .withColumnRenamed("SNo","s_no") \
                .withColumnRenamed("Stage","Stage") \
                .withColumnRenamed("PolicyNo","policy_no") \
                .withColumnRenamed("FileRefNo","file_ref_no") \
                .withColumnRenamed("LifeInsured","life_insured") \
                .withColumnRenamed("MedNonMedProposalStage","stage_of_cancer") \
                .withColumnRenamed("DateofDiagnosisorSurgery","date_of_diagnosis") \
                .withColumnRenamed("DateofIntimationHO","date_of_intimation") \
                .withColumnRenamed("ClaimAmountBASERIDER","amt_paid__involved") \
                .withColumnRenamed("RepudiationDateSettlementDate","settlement_date") \
                .withColumnRenamed("DOB","dob")


            logging.info(f"Writing fianl_df to {sink_path} ")
            sink_path=sink_path+"claims_otpci"
            final_df.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f" Data has written successfully to path {sink_path}")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)



