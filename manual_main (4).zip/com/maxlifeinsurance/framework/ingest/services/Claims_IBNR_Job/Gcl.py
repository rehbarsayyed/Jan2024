import logging
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class Gcl(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_gcl(self,src_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            logging.info("Loading gcl_claims file")         

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)

            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_gcl"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_gcl"))

            print("GCL date Str - ", date_str)
            print("GCL lag period - ", lag)
            print("GCL experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("GCL exposure_date - ", exposure_date)
            print("GCL exposure_start_date - ", exposure_start_date)
            print("GCL exposure_end_date - ", exposure_end_date)


            sdf = sdf.toDF(*(c.replace('.', '') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            sdf = sdf.withColumn("ClaimAmount", regexp_replace("ClaimAmount", "[^0-9.]", ""))

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss"))\
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit(exposure_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date(lit(exposure_end_date), "yyyy-MM-dd"))


            #Remove Non adm and Repudiation cases
            list_prod_codes_remove = ["Non Adm","Repudation","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))


            dod=stage_exclude.na.drop(subset=["DateofDeath"]) \
                .filter((col("DateofDeath")<=col("exposure_end_date")))\
                .toDF("Stage", "Policy", "File_Ref_No", "Life_Insured", "Date_of_Death", "date_of_intimation_ho", "Claim_Amount", "Repudiation_Date_Settlement_Date", "DOB", "Cause_of_Death", "Effective_Date", "Membership_No", "Group_Name", "Group_Asia_Member_No", "Group_Asia_Claim_No", "Loan_Type", "CLIENT_NO ", "DEPT_NO", "exposure_date", "exposure_end_date")


            dod=stage_exclude.na.drop(subset=["DateofDeath"]) \
                .filter((col("DateofDeath")<=col("exposure_date"))) \
                .withColumn("UIN", concat_ws("-", col("Policy").cast("string"), col("GroupAsiaMemberNo").cast("string"), col("DEPTNO").cast("string"))) \
                .withColumn("death_day",dayofmonth(col("DateofDeath"))) \
                .withColumn("death_year",year(col("DateofDeath"))) \
                .withColumn("death_month",month(col("DateofDeath"))) \
                .withColumnRenamed("ClaimAmount","SA") \
                .withColumnRenamed("DateofIntimationHO","date_of_intimation") \
                .withColumnRenamed("DateofDeath","date_of_death") \
                .withColumn("Month_Flag",floor(months_between(col("date_of_intimation"),col("date_of_death")))) \
                .select("UIN","Policy","death_day","death_year","death_month","SA","date_of_intimation","Month_Flag","date_of_death")
                # .filter((col("DateofDeath")<=col("exposure_date")))
                # .withColumn("UIN", concat_ws("-", col("Policy"), col("MembershipNo")))


            sink_path = sink_path+"claims_gcl"
            logging.info(f"Writing fianl_df to {sink_path} ")
            dod.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f" Data has written successfully to path {sink_path} ")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)