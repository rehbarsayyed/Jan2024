import logging
import sys
import pandas as pd
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class itdytd_prot_non_prot(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_itdytd_prot_non_prot(self, overall_claims_itdytd_input_file_path, mort_ref_file_path, val_health_file_path, val_gmi_file_path, val_trad_file_path, val_ul_file_path, claims_prot_non_prot_sink_path):
        try:
            spark = self.spark
            config = self.Config

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            logging.info("Loading claims_itdytd protection/non-protection")

            print(f"Reading ITD-YTD Overall Claims - {overall_claims_itdytd_input_file_path}")
            itdytd_claims = spark.read.option("header","true").csv(overall_claims_itdytd_input_file_path)

            print(f"Reading val_health - {val_health_file_path}")
            health = spark.read.parquet(val_health_file_path)

            print(f"Reading val_gmi - {val_gmi_file_path}")
            gmi = spark.read.parquet(val_gmi_file_path)

            print(f"Reading val_trad - {val_trad_file_path}")
            trad = spark.read.parquet(val_trad_file_path).filter(col("rider_base_plan")=="Base")

            print(f"Reading val_ul - {val_ul_file_path}")
            ul = spark.read.parquet(val_ul_file_path)

            print(f"Reading mort_ref - {mort_ref_file_path}")
            mort_ref = spark.read.option("header","True").csv(mort_ref_file_path)
    
            print("Overall ITD-YTD Claims Count", itdytd_claims.count())

            
            health.createOrReplaceTempView("health")
            gmi.createOrReplaceTempView("gmi")
            trad.createOrReplaceTempView("trad")
            ul.createOrReplaceTempView("ul")
            
            plcy_cmmrcl_dtl_union = spark.sql("SELECT DISTINCT policy_number AS policy_no, plan_id FROM UL UNION SELECT DISTINCT policy_number AS policy_no, plan_id FROM TRAD UNION SELECT DISTINCT policy_number AS policy_no, plan_id FROM GMI UNION SELECT DISTINCT policy_number AS policy_no, plan_id FROM health")
 
            plcy_cmmrcl_dtl = plcy_cmmrcl_dtl_union.dropDuplicates()
            w2 = Window.partitionBy("policy_no").orderBy(col("plan_id"))
            plcy_cmmrcl_dtl1 = plcy_cmmrcl_dtl.withColumn("row",row_number().over(w2)).filter(col("row") == 1).drop("row")

            claims1 = itdytd_claims.join(plcy_cmmrcl_dtl1,"policy_no",how="left")

            mort = mort_ref.select("plan_id","product_type_1")
            final_claims = claims1.join(mort,"plan_id",how="left")

            non_protection_claims = final_claims.filter((col("product_type_1")!="Non Par Protection") | (col("product_type_1").isNull()))
            non_protection_claims = non_protection_claims.drop("plan_id","product_type_1")
            
            protection_claims = final_claims.filter(col("product_type_1")=="Non Par Protection")
            protection_claims = protection_claims.drop("plan_id","product_type_1")

            prot_sink_path = claims_prot_non_prot_sink_path + "claims_itdytd_prot/"
            print("Protection DF count - ", protection_claims.count())
            print(f"Writing DF to - {prot_sink_path}")
            protection_claims.coalesce(1).write.option("header","True").mode("overwrite").csv(prot_sink_path)

            non_prot_sink_path = claims_prot_non_prot_sink_path + "claims_itdytd_non_prot/"
            print("Non-Protection DF count - ", non_protection_claims.count())
            print(f"Writing DF to - {non_prot_sink_path}")
            non_protection_claims.coalesce(1).write.option("header","True").mode("overwrite").csv(non_prot_sink_path)

        
            logging.info(f" Data has written successfully to path {claims_prot_non_prot_sink_path}")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)