import logging
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb


class Rider(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_rider(self,src_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            logging.info("Loading claims_rider file")

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)

            sdf = sdf.toDF(*(c.replace('.', '') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            # lag=1
            # experience_study_period = 12
            # exposure_start_date = "2021-04-01"
            # exposure_end_date = "2022-03-31"
            
            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_rider"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_rider"))

            print("RIDER date Str - ", date_str)
            print("RIDER lag period - ", lag)
            print("RIDER experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("RIDER exposure_date - ", exposure_date)
            print("RIDER exposure_start_date - ", exposure_start_date)
            print("RIDER exposure_end_date - ", exposure_end_date)

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("INFORCEDATE",to_date(col("INFORCEDATE"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit(exposure_date), "yyyy-MM-dd")) \
                .withColumn("DateofIntimationGO",to_date(col("DateofIntimationGO"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("CompleteDocsClarificationReceiveddate",to_date(col("CompleteDocsClarificationReceiveddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("InvestReportrecddate",to_date(col("InvestReportrecddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateProposalSigned",to_date(col("DateProposalSigned"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("PolicyIssueDate",to_date(col("PolicyIssueDate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_start_date",to_date(lit(exposure_start_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date(lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofDiagnosisorSurgery",to_date(col("DateofDiagnosisorSurgery"),"yyyy-MM-dd HH:mm:ss"))


            #Remove Non adm and Repudiation cases
            list_prod_codes_remove = ["Non Adm","Repudiation","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))

            # Filter DOD till investigation period only. Remove "NA" cases also
            dod=stage_exclude.na.drop(subset=["DateofDeath"]).filter((col("DateofDeath")<=col("exposure_date")))

            # Remove cases where "PAB Amount"=0.
            PAB=dod.filter(col("PABAmount")!=0) \
                .withColumnRenamed("PolicyNo","POLICY_NUMBER") \
                .withColumnRenamed("CategoryofDeath","Category_of_Death") \
                .withColumnRenamed("DateofDeath","Date_of_Death") \
                .withColumnRenamed("DateofIntimationHO","Date_of_Intimation_HO") \
                .withColumnRenamed("EffectiveDate","EDC") \
                .withColumnRenamed("DOB","L2BI_DOB")

            PAB1=PAB.withColumn("Month_Flag",floor(months_between(col("Date_of_Intimation_HO"),col("Date_of_Death")))) \
                .withColumn("death_day",dayofmonth(col("Date_of_Death"))) \
                .withColumn("death_year", year(col("Date_of_Death"))) \
                .withColumn("death_month", month(col("Date_of_Death"))) \
                .withColumn("INTIMATION_DAY",dayofmonth(col("date_of_intimation_HO"))) \
                .withColumn("INTIMATION_MONTH",month(col("date_of_intimation_HO"))) \
                .withColumn("INTIMATION_YEAR", year(col("date_of_intimation_HO"))) \
                .withColumn("Amt_Paid__Involved",col("PABAmount"))\
                .select("POLICY_NUMBER","Amt_Paid__Involved","Category_of_Death","Date_of_Death","Date_of_Intimation_HO","Month_Flag","death_day","death_year",
                        "death_month","EDC","INTIMATION_DAY","INTIMATION_MONTH","INTIMATION_YEAR","L2BI_DOB","NatureofBasePolicy")



            # AGGEREGATION
            final_df=PAB1.groupBy(col("POLICY_NUMBER")).agg(sum(col("Amt_Paid__Involved")).alias("Amt_Paid__Involved"),
                                                            first(col("Category_of_Death")).alias("Category_of_Death"),
                                                            first(col("Date_of_Death")).alias("Date_of_Death"),
                                                            first(col("Date_of_Intimation_HO")).alias("Date_of_Intimation_HO"),
                                                            first(col("Month_Flag")).alias("Month_Flag"),
                                                            first(col("death_day")).alias("death_day"),
                                                            first(col("death_year")).alias("death_year"),
                                                            first(col("death_month")).alias("death_month"),
                                                            first(col("EDC")).alias("EDC"),
                                                            first(col("INTIMATION_DAY")).alias("INTIMATION_DAY"),
                                                            first(col("INTIMATION_MONTH")).alias("INTIMATION_MONTH"),
                                                            first(col("INTIMATION_YEAR")).alias("INTIMATION_YEAR"),
                                                            first(col("L2BI_DOB")).alias("L2BI_DOB"),
                                                            first(col("NatureofBasePolicy")).alias("Nature_of_Base_Policy"))


            logging.info(f"Writing fianl_df to {sink_path} ")
            sink_path=sink_path+"claims_rider"
            final_df.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f" Data has written successfully to path {sink_path} ")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)