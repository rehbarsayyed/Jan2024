import logging
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class Cdr(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_cdr(self,src_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            logging.info("Loading cdr_claims_ file")

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)


            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            sdf = sdf.toDF(*(c.replace('.', '') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            # lag=3
            # experience_study_period = 12

            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_cdr"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_cdr"))

            print("CDR date Str - ", date_str)
            print("CDR lag period - ", lag)
            print("CDR experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("CDR exposure_date - ", exposure_date)
            print("CDR exposure_start_date - ", exposure_start_date)
            print("CDR exposure_end_date - ", exposure_end_date)

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("INFORCEDATE",to_date(col("INFORCEDATE"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit("2021-09-30"), "yyyy-MM-dd")) \
                .withColumn("DateofIntimationGO",to_date(col("DateofIntimationGO"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("CompleteDocsClarificationReceiveddate",to_date(col("CompleteDocsClarificationReceiveddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("InvestReportrecddate",to_date(col("InvestReportrecddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateProposalSigned",to_date(col("DateProposalSigned"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("PolicyIssueDate",to_date(col("PolicyIssueDate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_start_date",to_date(lit(exposure_start_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date(lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofDiagnosisorSurgery",to_date(col("DateofDiagnosisorSurgery"),"yyyy-MM-dd HH:mm:ss"))


            #Remove Non_adm Claims
            list_prod_codes_remove = ["Non Adm","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))


            # Include Effective Date within exposure_period
            effective_date=stage_exclude.filter(col("exposure_start_date")<=col("EffectiveDate")).filter((col("EffectiveDate")<=col("exposure_end_date")))

            # Include Date of death within exposure period and remove "NA" DOD
            dod=effective_date.na.drop(subset=["DateofDeath"]) \
                .filter(col("exposure_start_date")<=col("DateofDeath")).filter((col("DateofDeath")<=col("exposure_end_date")))

            # Remove "Suicide" category of death
            cod=dod.filter(~col("CategoryofDeath").contains('Suicide'))


            # Remove Health and Annuity products
            li=["Max Life Guaranteed Lifetime Income Plan - Single Life Deferred Annuity (Comm)",
                "Max Life Guaranteed Lifetime Income Plan-Joint Life Immediate Annuity ROP (Comm)",
                "Max Life Guaranteed Lifetime Income Plan - Single Life Immediate Annuity ROP",
                "Max Life Guaranteed Lifetime Income Plan-Single Life Immediate Annuity ROP(Comm)",
                "Max Life Guaranteed Lifetime Income Plan - Single Life Immediate Annuity with ROP",
                "Max Life Guaranteed Lifetime Income Plan - Joint Life Immediate Annuity with ROP (Comm)",
                "Max Life Guaranteed Lifetime Income Plan - Single Life Deferred Annuity",
                "Max Life Guaranteed Lifetime Income Plan - Single Life Immediate Annuity with ROP (Comm)",
                "Max Life Cancer Insurance Plan"]

            nobp=cod.filter(~col("NatureofBasePolicy").contains("Annuity")).filter(~col("NatureofBasePolicy").contains("Cancer")) \
                .withColumnRenamed("PolicyNo","policy_no") \
                .withColumn("BaseAmountAccountValue",when(upper(col("BaseAmountAccountValue"))=="NAN",lit(0)).otherwise(col("BaseAmountAccountValue"))) \
                .withColumn("PUAofOPPB",when(upper(col("PUAofOPPB"))=="NAN",lit(0)).otherwise(col("PUAofOPPB"))) \
                .withColumn("PUAofBonusAccValue",when(upper(col("PUAofBonusAccValue"))=="NAN",lit(0)).otherwise(col("PUAofBonusAccValue"))) \
                .withColumn("PremiumRefund",when(upper(col("PremiumRefund"))=="NAN",lit(0)).otherwise(col("PremiumRefund"))) \
                .withColumn("UnpaidPremiumSurrenderCharge",when(upper(col("UnpaidPremiumSurrenderCharge"))=="NAN",lit(0)).otherwise(col("UnpaidPremiumSurrenderCharge")))


            joined_df=nobp
            final_df=joined_df.withColumn("COVID_IND",col("covidyesno"))


            # Paste filtered policies in "CDR_Claims" tab. Change Stage to Death for all headers except for "Repudiation"
            
            stage_df=final_df.withColumn("Stage",when(col("Stage")!="Repudiation",lit("Death")).otherwise(col("Stage")))\
                .withColumn("Amt_Paid__Involved",col("BaseAmountAccountValue")+col("PUAofOPPB")+col("PUAofBonusAccValue")+col("PremiumRefund")+col("WaiverofPremiumPayorRider")-col("UnpaidPremiumSurrenderCharge"))\
                .select("policy_no","Stage","DateofDeath","DateofIntimationHO","RepudiationDateSettlementDate",
                        "CategoryofDeath","Amt_Paid__Involved","COVID_IND") \
                .withColumn("death_day",dayofmonth(col("DateofDeath"))) \
                .withColumn("death_year", year(col("DateofDeath"))) \
                .withColumn("death_month", month(col("DateofDeath")))\
                .toDF("policy_no", "Stage", "Date_of_Death", "date_of_intimation_ho", "Repudiation_Date_Settlement_Date", "Category_of_Death", "Amt_Paid__Involved", "COVID_IND", "death_day", "death_year", "death_month")

            sink_path = sink_path+"claims_cdr"

            logging.info(f"Writing fianl_df to {sink_path} ")

            stage_df.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f"Data has written successfully to path {sink_path} ")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)
