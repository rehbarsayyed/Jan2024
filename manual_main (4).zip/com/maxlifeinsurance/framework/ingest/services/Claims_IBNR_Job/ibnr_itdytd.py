from pyspark.sql.window import Window
from pyspark.sql.functions import *
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import pandas as pd
import logging
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class ibnr_itdytd(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_ibnr_itdytd(self, ibnr_itdytd_input_file_path, overall_ibnr_sink_path, overall_ibnr_date_str):
        try:
            spark = self.spark
            config = self.Config

            logging.info("Loading IBNR")


            input_file = ibnr_itdytd_input_file_path
            output_folder = overall_ibnr_sink_path

            dfmt = '%Y-%m-%d'
            DOV =  pd.to_datetime(overall_ibnr_date_str,format = dfmt)

            print(f"Input Folder - {input_file}")
            print(f"Output Folder - {output_folder}")
            print(f"Date Str (DOV) - {str(DOV)}")

            start =  time.time()
            datafile = pd.read_csv(input_file, low_memory = False)

            PERIOD1 = 12

            datafile["death_month"] = datafile.death_month.map("{:02}".format)
            datafile['DTH_IND'] = (((datafile['death_year']).astype(str)) + datafile['death_month'].astype(str)).astype(int)

            SD_IND = DOV.year*100 + DOV.month
            data = {'DTH_IND':  range(1,28), 'IND': range(1,28)}

            Table1 = pd.DataFrame(data)

            if SD_IND%100==1:
                Table1.at[0, 'DTH_IND'] =  int(SD_IND /100)*100-100+12
            else:
                Table1.at[0, 'DTH_IND'] = SD_IND

            for i in range(1,27):
                if Table1.at[i-1, 'DTH_IND']%100==1:
                    Table1.at[i, 'DTH_IND'] =  int(Table1.at[i-1, 'DTH_IND'] /100)*100-100+12
                else:
                    Table1.at[i, 'DTH_IND'] = Table1.at[i-1, 'DTH_IND'] - 1

            Table1.to_csv(output_folder+"/datafile_test_stg.csv",header=True)


            datafile = pd.merge(datafile, Table1, how='right', on='DTH_IND')
            datafile = datafile.loc[datafile["Month_Flag"] <=12]
            datafile = datafile.loc[datafile["Month_Flag"] !=datafile["DTH_IND"]]
            datafile.to_csv(output_folder+"/datafile_test.csv",header=True)

            # For ITD_YTD
            Table2 = datafile.pivot_table(index='IND', columns='Month_Flag',values='amt_paid__involved' ,aggfunc = 'count')
            Table2A = datafile.pivot_table(index='IND', columns='Month_Flag',values='amt_paid__involved' ,aggfunc = 'sum')

            Table2 = Table2.fillna(value=0)
            Table2A = Table2A.fillna(value=0)

            Table2.to_csv(output_folder+"/Table2_test.csv",header=True)
            Table2A.to_csv(output_folder+"/Table2A_test.csv",header=True)

            Table3 = Table2.cumsum(axis = 1).copy()
            Table3A = Table2A.cumsum(axis = 1).copy()

            Table2.cumsum(axis = 1).to_csv(output_folder+"/Table2NEW.csv",header=True)

            Table3.to_csv(output_folder+"/table3_test.csv",header=True)
            Table3A.to_csv(output_folder+"/table3A_test.csv",header=True)

            data = {'ARR1':  range(0,12), 'ARR2': range(0,12), 'ARR3': range(0,12), 'ARR4': range(0,12)}
            Table4 = pd.DataFrame(data)
            Table4A = pd.DataFrame(data)

            for i in range(0,12):
                Table4.at[i, 'ARR1'] = 0
                Table4.at[i, 'ARR2'] = 0
                Table4.at[i, 'ARR3'] = 0
                Table4A.at[i, 'ARR1'] = 0
                Table4A.at[i, 'ARR2'] = 0
                Table4A.at[i, 'ARR3'] = 0
                if i == 0:
                    start = 3
                    end = 15

                    for j in range(start,end):
                        Table4.at[i, 'ARR1']  = Table4.at[i, 'ARR1']  + Table3.at[j,i]
                        Table4A.at[i, 'ARR1'] = Table4A.at[i, 'ARR1'] + Table3A.at[j,i]
                        
                    for j in range(start,end):
                        Table4.at[i, 'ARR2']  = Table4.at[i, 'ARR2']  + Table3.at[j,i+1]
                        Table4A.at[i, 'ARR2'] = Table4A.at[i, 'ARR2'] + Table3A.at[j,i+1]

                else:
                    start = i+3
                    end = i + PERIOD1 +3

                    for j in range(start,end):
                        Table4.at[i, 'ARR1']  = Table4.at[i, 'ARR1']  + Table3.at[j,i]
                        Table4A.at[i, 'ARR1'] = Table4A.at[i, 'ARR1'] + Table3A.at[j,i]

                    for j in range(start,end):
                        Table4.at[i, 'ARR2']  = Table4.at[i, 'ARR2']  + Table3.at[j,i+1]
                        Table4A.at[i, 'ARR2'] = Table4A.at[i, 'ARR2'] + Table3A.at[j,i+1]

            Table4.to_csv(output_folder+"/table4_test.csv",header=True)
            Table4A.to_csv(output_folder+"/table4A_test.csv",header=True)

            Table4['ARR3']  = Table4['ARR3'].astype(float)
            Table4['ARR4']  = Table4['ARR4'].astype(float)
            Table4A['ARR3'] = Table4A['ARR3'].astype(float)
            Table4A['ARR4'] = Table4A['ARR4'].astype(float)

            for i in range(0,12):

                Table4.at[i, 'ARR3']  = Table4.at[i, 'ARR2']  / Table4.at[i, 'ARR1']
                Table4A.at[i, 'ARR3'] = Table4A.at[i, 'ARR2'] / Table4A.at[i, 'ARR1']

                Table4.to_csv(output_folder+"/table4_ratio.csv",header=True)
                Table4A.to_csv(output_folder+"/table4A_ratio.csv",header=True)

            for i in range(11,-1,-1):
                if i==11:
                    Table4.at[i, 'ARR4']  =  Table4.at[i, 'ARR3']
                    Table4A.at[i, 'ARR4'] =  Table4A.at[i, 'ARR3']

                else:
                    Table4.at[i, 'ARR4']  = Table4.at[i+1, 'ARR4']  * Table4.at[i, 'ARR3']
                    Table4A.at[i, 'ARR4'] = Table4A.at[i+1, 'ARR4'] * Table4A.at[i, 'ARR3']

            Table4.to_csv(output_folder+"/table4_cumm.csv",header=True)
            Table4A.to_csv(output_folder+"/table4A_cumm.csv",header=True)

            Table4=Table4.drop(labels=[0,0],axis=0)
            Table4A=Table4A.drop(labels=[0,0],axis=0)

            Table4=Table4.drop(columns=["ARR1","ARR2"])
            Table4A=Table4A.drop(columns=["ARR1","ARR2"])
            Table4=Table4.applymap(str)
            Table4A=Table4A.applymap(str)

            df=spark.createDataFrame(Table4)
            ibnr_df=df.withColumnRenamed("ARR4","ibnr_Count")

            windowSpec  = Window.orderBy(col("ibnr_count").desc())

            final_df_cnt=ibnr_df.withColumn("cnt",row_number().over(windowSpec)).select("cnt","ibnr_count")
            print("Writing in - itd_ytd_ibnr_gcl_count")
            final_df_cnt.coalesce(1).write.option("header","true").mode("overwrite").csv(output_folder+"/itd_ytd_ibnr_gcl_count")

            df=spark.createDataFrame(Table4A)
            ibnr_df=df.withColumnRenamed("ARR4","ibnr_Amount")

            windowSpec  = Window.orderBy(col("ibnr_Amount").desc())

            final_df_amt=ibnr_df.withColumn("cnt",row_number().over(windowSpec)).select("cnt","ibnr_amount")
            print("Writing in - itd_ytd_ibnr_gcl_amount")
            final_df_amt.coalesce(1).write.option("header","true").mode("overwrite").csv(output_folder+"/itd_ytd_ibnr_gcl_amount")

            # repartition the DataFrames
            final_df_cnt = final_df_cnt.repartition(2, "cnt")
            final_df_amt = final_df_amt.repartition(2, "cnt")

            merge_df = final_df_cnt.join(final_df_amt,"cnt",how = "inner")
            merge_df = merge_df.withColumn("ibnr_count",round(col("ibnr_count"),2)).withColumn("ibnr_amount",round(col("ibnr_amount"),2))
            
            print("Writing final DF - itd_ytd_ibnr_gcl_final")

            merge_df.coalesce(1).write.option("header","true").mode("overwrite").csv(output_folder+"/itd_ytd_ibnr_gcl_final")

            print("Final IBNR is -")
            merge_df.show(50,False)

            logging.info(f" Data has written successfully to path {output_folder} ")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)