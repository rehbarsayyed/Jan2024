import logging
import sys
import pandas as pd
from pyspark.sql.functions import *
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb

class Itd_Ytd(object):

    def __init__(self, spark, Config):
        self.spark = spark
        self.Config = Config

    def load_itdytd(self,src_data,sink_path,date_str):
        try:
            spark = self.spark
            config = self.Config

            from pyspark.sql.functions import col
            import pyspark.sql.functions as F
            import re

            logging.info("Loading itd_ytd_claims file")

            df_pol_output=src_data
            df=df_pol_output.applymap(str)
            sdf = spark.createDataFrame(df)

            sdf = sdf.toDF(*(c.replace('.', '') for c in sdf.columns))
            sdf = sdf.select([F.col(col).alias(re.sub("[^0-9a-zA-Z$]+","",col)) for col in sdf.columns])

            # lag=1
            # experience_study_period = 12
            # exposure_start_date = "2021-04-01"
            # exposure_end_date = "2022-03-31"
            # exposure_date = exposure_end_date

            date_str = date_str
            lag = int(config.get('OVERALL_CLAIMS', f"lag_itdytd"))
            experience_study_period = int(config.get('OVERALL_CLAIMS', f"experience_study_period_itdytd"))

            print("ITD_YTD date Str - ", date_str)
            print("ITD_YTD lag period - ", lag)
            print("ITD_YTD experience_study_period - ", experience_study_period)

            exposure_start_date,exposure_end_date = Jb.getDate(lag,date_str,experience_study_period)
            exposure_date = exposure_end_date

            print("ITD_YTD exposure_date - ", exposure_date)
            print("ITD_YTD exposure_start_date - ", exposure_start_date)
            print("ITD_YTD exposure_end_date - ", exposure_end_date)

            df1=sdf.withColumn("DateofDeath",to_date(col("DateofDeath"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateofIntimationHO",to_date(col("DateofIntimationHO"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("RepudiationDateSettlementDate",to_date(col("RepudiationDateSettlementDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DOB",to_date(col("DOB"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("EffectiveDate",to_date(col("EffectiveDate"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("INFORCEDATE",to_date(col("INFORCEDATE"), "yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_date",to_date(lit(exposure_date), "yyyy-MM-dd")) \
                .withColumn("DateofIntimationGO",to_date(col("DateofIntimationGO"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("CompleteDocsClarificationReceiveddate",to_date(col("CompleteDocsClarificationReceiveddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("InvestReportrecddate",to_date(col("InvestReportrecddate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("DateProposalSigned",to_date(col("DateProposalSigned"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("PolicyIssueDate",to_date(col("PolicyIssueDate"),"yyyy-MM-dd HH:mm:ss")) \
                .withColumn("exposure_start_date",to_date(lit(exposure_start_date), "yyyy-MM-dd")) \
                .withColumn("exposure_end_date",to_date(lit(exposure_end_date), "yyyy-MM-dd")) \
                .withColumn("DateofDiagnosisorSurgery",to_date(col("DateofDiagnosisorSurgery"),"yyyy-MM-dd HH:mm:ss"))


            # Removed Repudiated ,NonAdmissible
            list_prod_codes_remove = ["Non Adm","Repudiation","Non adm"]
            stage_exclude = df1.filter(~df1['stage'].isin(list_prod_codes_remove))

            # Remove date of death w/c is not in exposure period, say Jul'21 if we're analysing it as at jul'21
            dod=stage_exclude.na.drop(subset=["DateofDeath"]).filter((col("DateofDeath")<=col("exposure_date")))

            #Removed everything except WoP Rider amount equal to 0 or Blanks or "-" under header "Waiver of Premium/Payor Rider"
            # wop_li=[0,'',"-"]
            # wop_exclude=dod.filter(dod['WaiverofPremiumPayorRider'].isin(wop_li))
            wop_exclude=dod.filter((col("WaiverofPremiumPayorRider")==0) | (col("WaiverofPremiumPayorRider")=='0') | (col("WaiverofPremiumPayorRider")=='') | (col("WaiverofPremiumPayorRider")=='-'))\
                .withColumn("BaseAmountAccountValue",when(upper(col("BaseAmountAccountValue"))=="NAN",lit(0)).otherwise(col("BaseAmountAccountValue"))) \
                .withColumn("PUAofOPPB",when(upper(col("PUAofOPPB"))=="NAN",lit(0)).otherwise(col("PUAofOPPB"))) \
                .withColumn("PUAofBonusAccValue",when(upper(col("PUAofBonusAccValue"))=="NAN",lit(0)).otherwise(col("PUAofBonusAccValue"))) \
                .withColumn("PremiumRefund",when(upper(col("PremiumRefund"))=="NAN",lit(0)).otherwise(col("PremiumRefund"))) \
                .withColumn("UnpaidPremiumSurrenderCharge",when(upper(col("UnpaidPremiumSurrenderCharge"))=="NAN",lit(0)).otherwise(col("UnpaidPremiumSurrenderCharge"))) \
                .fillna(0,subset=["BaseAmountAccountValue","PUAofOPPB","PUAofBonusAccValue","PremiumRefund","UnpaidPremiumSurrenderCharge"])
            

            pivot_df=wop_exclude.groupBy(col("PolicyNo")) \
                .agg(sum(col("BaseAmountAccountValue")+col("PUAofOPPB")+col("PUAofBonusAccValue")+col("PremiumRefund")-col("UnpaidPremiumSurrenderCharge")).alias("amt_paid__involved"),max("DateofDeath").alias("Date_of_Death"),
                     max("DateofIntimationHO").alias("date_of_intimation"),max("RepudiationDateSettlementDate").alias("repudiation_date"),
                     max("DOB").alias("DOB"),first("Stage").alias("Stage"),first("CategoryofDeath").alias("Category_of_Death"),
                     first("EffectiveDate").alias("EDC"),first("NatureofBasePolicy").alias("Nature_of_Base_Policy"),
                     first("INFORCEDATE").alias("inforce_date"),first("exposure_date").alias("exposure_date"),first("Category").alias("Category")
                     ,first(col("covidyesno")).alias("covidyesno") )\
                .withColumn("Month_Flag",floor(months_between(col("date_of_intimation"),col("date_of_death")))) \
                .withColumn("death_day",dayofmonth(col("date_of_death"))) \
                .withColumn("death_year", year(col("Date_of_Death"))) \
                .withColumn("death_month", month(col("date_of_death")))


            joined_df=pivot_df
            final_df=joined_df.withColumnRenamed("covidyesno","COVID_IND")
            final_df1=final_df.withColumnRenamed("PolicyNo","policy_no")
 

            sink_path=sink_path+"claims_itdytd"
            logging.info(f"Writing fianl_df to {sink_path}")
            final_df1.coalesce(1).write.option("header","true").mode("overwrite").csv(sink_path)

            logging.info(f" Data has written successfully to path {sink_path} ")
            return "SUCCESS"

        except Exception as e:
            logging.error(e, exc_info=True)
            return "Exception -" + str(e)