from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from pyspark.sql.functions import *
import logging as log
from pyspark.sql.types import StructType, StructField, StringType, LongType
import json
import boto3
import re
from datetime import date


class Standard_Service(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def Standard_Run(self):
        try:
            jsonPath = self.Config.get('STANDARD_JOB_INPUT_PARAMS', 'tablemaster_path')
            tableList = Jb.getTableList(self.spark, jsonPath)
            JsonDataDf = Jb.GetJsonDf(self.spark, jsonPath)

            StageBucket = self.Config.get("STANDARD_JOB_INPUT_PARAMS", "standard.bucket.name")


            val_input_path = self.Config.get("STANDARD_JOB_INPUT_PARAMS", "val_input_year_month")
            datalake_input_path = self.Config.get("STANDARD_JOB_INPUT_PARAMS", "datalake_input_year_month")
            manual_input_path = self.Config.get("STANDARD_JOB_INPUT_PARAMS", "manual_input_year_month")


            for table in tableList:
                Source = str(table.split(",")[1]).strip(' ').lower()
                tableName = str(table.split(",")[3]).strip(' ').lower()
                baseTable = str(table.split(",")[5]).strip(' ').upper()
                write = str(table.split(",")[6]).strip(' ').upper()
                srcDirProp = str(Source).lower() + str('.raw.dir')
                srcDir = self.Config.get("STANDARD_JOB_INPUT_PARAMS", srcDirProp)
                if Source.lower() == "val":
                    BucketKey = srcDir + "/" + tableName + "/" + val_input_path + "/"
                elif Source.lower() == "datalake":
                    BucketKey = srcDir + "/" + tableName + "/" + datalake_input_path + "/"
                else:
                    BucketKey = srcDir + "/" + tableName + "/" + manual_input_path + "/"

                if baseTable == "Y":
                    Path = ""
                    if F.s3_File_Exists(StageBucket, BucketKey):
                        Path = StageBucket +"/"+ BucketKey + "/*"
                        Path = Path.replace("//", "/")
                        Path = "s3://" + Path
                        Path = Path.lower()
                        log.info("Reading from - {}. ".format(Path))
                        tblDF1 = self.spark.read.parquet(Path)
                        tblDF1.createOrReplaceTempView(tableName)

                    else:
                        log.info(":::: Path not found - {}. ".format(Path))
                        continue

                sqlDF = Jb.ExecuteSQLStatements(self.spark, JsonDataDf, tableName.upper())
                sqlDF.createOrReplaceTempView(tableName)


                if write == "Y":
                    finalDF1 = sqlDF.persist()
                    finalCount = finalDF1.count()
                    if finalCount > 0:
                        log.info(":::: count is {} for table {}".format(finalCount, tableName))
                        pk = Jb.getPrimaryColList(self.spark, JsonDataDf, Source, tableName)

                        target = str(table.split(",")[0]).strip(' ').lower()

                        sk = str(table.split(",")[2]).strip(' ').lower()
                        targetTableName = str(table.split(",")[4]).strip(' ').lower()
                        targetDirProp = str(target).upper() + str('.standard.tgt.dir')
                        targetDir = self.Config.get("STANDARD_JOB_OUTPUT_PARAMS", targetDirProp)


                        op_yr_mnth = self.Config.get("STANDARD_JOB_OUTPUT_PARAMS", "output.year_month")
                        pathToFolder = "s3://" + StageBucket + "/" + targetDir + targetTableName + "/" + op_yr_mnth + "/"

                        res = Jb.writeHudiDf(finalDF1, pk, "standard_job", tableName, sk, pathToFolder)
                    else:
                        log.info(":::: No data to write for table {}".format(tableName))
                    finalDF1.unpersist()

                    if res.upper() == "SUCCESS":
                        log.info(":::: Data written for table {} successfully".format(tableName))

                    else:
                        return "Failed -Failed to write data to table {}".format((tableName))
                    
                else:
                    log.info(":::: No data to write for table {}".format(tableName))



            return "SUCCESS"

        except Exception as e:
            log.error(e, exc_info=True)
            return ("Failed -" + str(e))