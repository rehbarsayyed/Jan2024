from com.maxlifeinsurance.framework.ingest.services.DL_Preprocess_Job.DL_Preprocess_Service import DL_Preprocess_Service
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
import logging as logs
import yaml

class DL_Preprocess_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            job_name = str(args['jobName']).strip(' ')
            logs.info("::::Job {} has been started.".format(job_name))

            
            file_list = self.Config.get('DL_PREPROCEES_JOB_INPUT_PARAMS', "files_list")

            file_name_list= [x.strip() for x in file_list.split(',')]

            logs.info("Files to be executed are -")
            for i in range(1, len(file_name_list)+1):
                print(str(i) + " - "+ file_name_list[i-1])

            success_files=[]
            fnf_files=[]
            failed_files=[]
            
            obj = DL_Preprocess_Service(self.spark, self.glueContext, self.Config)
            
            for file_name in file_name_list:
                res = obj.DL_Preprocess_Ingest(file_name)

                if str(res).upper() == "FNF":
                    logs.error(f"File not found  to preprocess {file_name}  file".format(file_name=file_name))
                    fnf_files.append(file_name)
                elif str(res).upper() == "SUCCESS":
                    logs.info(f"::::Job {job_name} has Successfully Completed for file {file_name}.".format(job_name,file_name))
                    success_files.append(file_name)
                else:
                    logs.error(f"Failed to preprocess {file_name} file".format(file_name=file_name))
                    failed_files.append(file_name)


            print(f"Job ran successfully for {success_files}".format(success_files))
            print(f"Job FNF for {fnf_files}".format(fnf_files))
            print(f"Job failed for {failed_files}".format(failed_files))

            return "SUCCESS"

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "DL_PREPROCESS_JOB"
