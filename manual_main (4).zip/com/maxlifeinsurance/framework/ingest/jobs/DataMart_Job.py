from com.maxlifeinsurance.framework.ingest.services.DataMart_Job.DataMart_Service import DataMart_Service
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
import logging as logs

class Val_Extract_DB_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.Config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            job_name = str(args['jobName']).strip(' ')
            logs.info("::::Job {} has been started.".format(job_name))
 
            obj = DataMart_Service(self.spark, self.glueContext, self.Config)
            res = obj.DataMart_Run()

            return "SUCCESS"

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "DATAMART_JOB"
