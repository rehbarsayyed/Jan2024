from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Cc import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Cdr import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Gcl import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Itd_Ytd import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Otpci import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.Rider import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.ibnr_itdytd import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.ibnr_gcl import *
from com.maxlifeinsurance.framework.ingest.services.Claims_IBNR_Job.itdytd_prot_non_prot import *
from com.maxlifeinsurance.framework.utils.DFUtils import DFUtils as F
from com.maxlifeinsurance.framework.utils.JobUtils import JobUtils as Jb
import logging as logs

class Claims_IBNR_Job(object):
    def __init__(self, spark, glueContext, Config):
        self.spark = spark
        self.config = Config
        self.glueContext = glueContext

    def execute(self, args):
        try:
            logs.basicConfig()
            logs.getLogger().setLevel(logs.INFO)

            res = "SUCCESS"

            # Reading Config for Overall Claims

            itd_drilldown_file_path = self.config.get('OVERALL_CLAIMS', f"itd_drilldown_ind.src.path")
            group_credit_life_file_path = self.config.get('OVERALL_CLAIMS', f"itd_group_credit_life.src.path")
            stg_cncr_file_path = self.config.get('OVERALL_CLAIMS', f"stg_cncr.src.path")

            overall_claims_sink_path = self.config.get('OVERALL_CLAIMS_OUTPUT', f"claims_sink.tgt.path")
            overall_claims_date_str = self.config.get('OVERALL_CLAIMS', f"claims_date_str")

            run_cc = self.config.get('OVERALL_CLAIMS', f"run_cc")
            run_cdr = self.config.get('OVERALL_CLAIMS', f"run_cdr")
            run_gcl = self.config.get('OVERALL_CLAIMS', f"run_gcl")
            run_itdytd = self.config.get('OVERALL_CLAIMS', f"run_itdytd")
            run_otpci = self.config.get('OVERALL_CLAIMS', f"run_otpci")
            run_rider = self.config.get('OVERALL_CLAIMS', f"run_rider")



            # Reading Config for Overall IBNR

            ibnr_itdytd_input_file_path = self.config.get('OVERALL_IBNR', f"ibnr_itdytd_input.src.path")
            ibnr_gcl_input_file_path = self.config.get('OVERALL_IBNR', f"ibnr_gcl_input.src.path")

            overall_ibnr_date_str = self.config.get('OVERALL_IBNR', f"ibnr_date_str")
            overall_ibnr_sink_path = self.config.get('OVERALL_IBNR_OUTPUT', f"ibnr_sink.tgt.path")

            run_ibnr_itdytd = self.config.get('OVERALL_IBNR', f"run_ibnr_itdytd")
            run_ibnr_gcl = self.config.get('OVERALL_IBNR', f"run_ibnr_gcl")




            # Reading Config for Protection / Non-Protection ITD_YTD Claims

            overall_claims_itdytd_input_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"overall_claims_itdytd_input.src.path")
            mort_ref_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"mort_ref.src.path")
            val_health_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"val_health.src.path")
            val_gmi_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"val_gmi.src.path")
            val_trad_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"val_trad.src.path")
            val_ul_file_path = self.config.get('CLAIMS_PROT_NON_PROT', f"val_ul.src.path")

            run_itdytd_prot_non_prot = self.config.get('CLAIMS_PROT_NON_PROT', f"run_itdytd_prot_non_prot")
            claims_prot_non_prot_sink_path = self.config.get('CLAIMS_PROT_NON_PROT_OUTPUT', f"claims_prot_non_prot_sink.tgt.path")




            # Reading Config for Protection/Non-Protection IBNR

            itdytd_prot_ibnr_input_file_path = self.config.get('PROT_NON_PROT_IBNR', f"itdytd_prot_ibnr_input.src.path")
            itdytd_non_prot_ibnr_input_file_path = self.config.get('PROT_NON_PROT_IBNR', f"itdytd_non_prot_ibnr_input.src.path")

            prot_non_prot_ibnr_date_str = self.config.get('PROT_NON_PROT_IBNR', f"prot_non_prot_ibnr_date_str")
            itdytd_prot_non_prot_ibnr_sink = self.config.get('PROT_NON_PROT_IBNR_OUTPUT', f"itdytd_prot_non_prot_ibnr_sink.tgt.path")

            run_itdytd_prot_ibnr = self.config.get('PROT_NON_PROT_IBNR', f"run_itdytd_prot_ibnr")
            run_itdytd_non_prot_ibnr = self.config.get('PROT_NON_PROT_IBNR', f"run_itdytd_non_prot_ibnr")




            # For Overall Claims 
            if ((run_cc.strip().upper()=='YES') or (run_cdr.strip().upper()=='YES') or (run_otpci.strip().upper()=='YES') or (run_rider.strip().upper()=='YES') or (run_itdytd.strip().upper()=='YES') or (run_gcl.strip().upper()=='YES')):
            
                logs.info("Reading itd_drilldown file - " + str(itd_drilldown_file_path))
                itd_drilldown_file_data = pd.read_excel(itd_drilldown_file_path,sheet_name = "Sheet1")
                
                logs.info("Reading group_credit_life file - " + str(group_credit_life_file_path))
                group_credit_life_file_data = pd.read_excel(group_credit_life_file_path, sheet_name="Sheet1", keep_default_na=False)

                logs.info("Reading stg_cncr file - " + str(stg_cncr_file_path))
                stg_cncr_file_data = pd.read_excel(stg_cncr_file_path,sheet_name = "Sheet1",keep_default_na=False)


                if run_cc.strip().upper() == 'YES':
                    obj_cc = CC(self.spark,self.config)
                    res = obj_cc.load_cc(itd_drilldown_file_data, stg_cncr_file_data, overall_claims_sink_path, overall_claims_date_str)

                if run_cdr.strip().upper() == 'YES':
                    obj_cdr = Cdr(self.spark,self.config)
                    res= obj_cdr.load_cdr(itd_drilldown_file_data, overall_claims_sink_path, overall_claims_date_str)

                if run_otpci.strip().upper() == 'YES':
                    obj_otpci = Otcpi(self.spark,self.config)
                    res= obj_otpci.load_otpci(itd_drilldown_file_data, overall_claims_sink_path, overall_claims_date_str)

                if run_rider.strip().upper() == 'YES':
                    obj_rider = Rider(self.spark,self.config)
                    res= obj_rider.load_rider(itd_drilldown_file_data, overall_claims_sink_path, overall_claims_date_str)

                if run_itdytd.strip().upper() == 'YES':
                    obj_itdytd = Itd_Ytd(self.spark,self.config)
                    res= obj_itdytd.load_itdytd(itd_drilldown_file_data, overall_claims_sink_path, overall_claims_date_str)

                if run_gcl.strip().upper() == 'YES':
                    obj_gcl = Gcl(self.spark,self.config)
                    res= obj_gcl.load_gcl(group_credit_life_file_data, overall_claims_sink_path, overall_claims_date_str)



            # For Overall IBNR
            if ((run_ibnr_itdytd.strip().upper()=='YES') or (run_ibnr_gcl.strip().upper()=='YES')):

                if run_ibnr_itdytd.strip().upper() == 'YES':
                    overall_ibnr_sink_path_itd_ytd = overall_ibnr_sink_path+ "itd_ytd/"
                    obj_ibnr_itdytd = ibnr_itdytd(self.spark,self.config)
                    res= obj_ibnr_itdytd.load_ibnr_itdytd(ibnr_itdytd_input_file_path, overall_ibnr_sink_path_itd_ytd, overall_ibnr_date_str)

                if run_ibnr_gcl.strip().upper() == 'YES':
                    overall_ibnr_sink_path_gcl = overall_ibnr_sink_path+ "gcl/"
                    obj_ibnr_gcl = ibnr_gcl(self.spark,self.config)
                    res= obj_ibnr_gcl.load_ibnr_gcl(ibnr_gcl_input_file_path, overall_ibnr_sink_path_gcl, overall_ibnr_date_str)



            # For Claims ITD_YTD Protection / Non-Protection 
            if (run_itdytd_prot_non_prot.strip().upper()=='YES'):
                obj_itdytd_pnp = itdytd_prot_non_prot(self.spark,self.config)
                res= obj_itdytd_pnp.load_itdytd_prot_non_prot(overall_claims_itdytd_input_file_path, mort_ref_file_path, val_health_file_path, val_gmi_file_path, val_trad_file_path, val_ul_file_path, claims_prot_non_prot_sink_path)


            
            # For ITD-YTD Protection / Non-Protection IBNR
            if ((run_itdytd_prot_ibnr.strip().upper()=='YES') or (run_itdytd_non_prot_ibnr.strip().upper()=='YES')):

                if run_itdytd_prot_ibnr.strip().upper() == 'YES':
                    itdytd_prot_ibnr_sink = itdytd_prot_non_prot_ibnr_sink+ "itd_ytd_prot/"
                    obj_ibnr_itdytd = ibnr_itdytd(self.spark,self.config)
                    res= obj_ibnr_itdytd.load_ibnr_itdytd(itdytd_prot_ibnr_input_file_path, itdytd_prot_ibnr_sink, prot_non_prot_ibnr_date_str)

                if run_itdytd_non_prot_ibnr.strip().upper() == 'YES':
                    itdytd_non_prot_ibnr_sink = itdytd_prot_non_prot_ibnr_sink+ "itd_ytd_non_prot/"
                    obj_ibnr_itdytd = ibnr_itdytd(self.spark,self.config)
                    res= obj_ibnr_itdytd.load_ibnr_itdytd(itdytd_non_prot_ibnr_input_file_path, itdytd_non_prot_ibnr_sink, prot_non_prot_ibnr_date_str)


            return res

        except Exception as e:
            logs.error(e, exc_info=True)
            return ("Failed -" + str(e))

    # job name keyword
    jobName = "CLAIMS_IBNR_JOB"
